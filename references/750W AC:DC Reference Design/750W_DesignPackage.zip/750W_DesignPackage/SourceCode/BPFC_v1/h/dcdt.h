
#include "defines.h"

/* Voltage Loop Compensation
  Compensator Type:  PID
      Entry                Value  
    ---------            ---------
  Kp                     1.9940e+00
  Ki                     1.0000e+02
  Kd                     0.0000e+00
  Kd                     0.0000e+00
  Gain(Kdc)              1
  PWM Frequency          1.0000e+05
  PWM Sampling Ratio     8
  Sampling Frequency     1.2500e+04
  PWM Max Resolution     1.0600e-09
  Computational Delay    1.1000e-06
  Control Output Min.    0
  Control Output Max.    22300
 

  PWM Calculations
      Name                Value  
    ---------           ---------
  Bits of Resolution    16.204
  Gain                  1.325e-05


  s-domain transfer function

               (             Ki )
  H(s) = Kdc X (Kp + Kd(s) + ---)
               (              s )

                 (                         1.00e+02 )
  H(s) = 1.000 X (1.99e+00 + 0.00e+00(s) + ---------)
              (                                s    )



  Digital Compensator Coefficients

  Name    Value     Normalized    Q15      Hex
  ----    -----     ----------    ---      ---
  Ka      2.002     1.000         32764    0x7FFC
  Kb      -1.994    -0.996        -32633   0x8087
  Kc      0.000     0.000         0        0x0000


  z-domain transfer function

         u(z)  B0 + B1z^(-1) + B2z^(-2)
  H(z) = --- = ------------------------
         e(z)  A0 - A1z^(-1) - A2z^(-2)

          (2.002) + (-1.994)z^(-1) + (0.000)z^(-2)
  H(z) = ---------------------------------------------
          1 - z^(-1) - (0.000)z^(-2)

**/

/* PFC Outer Voltage Loop Compensation Definitions */
#define PFCVOLTCOEFFA1                          0x1FFF
#define PFCVOLTCOEFFA2                          0
#define PFCVOLTCOEFFB0                          0x1FFF
#define PFCVOLTCOEFFB1                         -8100
#define PFCVOLTCOEFFB2                          0
#define PFCVOLTPOSTSHIFT                        -2
#define PFCVOLTPOSTSCALER                       0x7FFF 

#define PFCVOLTMINCLAMP                         0
#define PFCVOLTMAXCLAMP                         25000 // 22300 - 820W Clamp

/*  Inner Current Loop Compensator
  Compensator Type:  2P2Z
      Entry                Value  
    ---------            ---------
  Pole 0                 2.4397e+03 Hz
  Pole 2                 2.0000e+04 Hz
  Zero 1                 1.7500e+03 Hz
  Gain(Kdc)              1.000
  Warp                   false
  PWM Frequency          1.0000e+05
  PWM Sampling Ratio     1
  Sampling Frequency     1.0000e+05
  PWM Max Resolution     1.0600e-09
  Computational Delay    1.3500e-06
  Gate Drive Delay       1.5000e-07
  Control Output Min.    0
  Control Output Max.    32767
  Kuc Gain               5.0517e+01
  Use Kuc Gain           false


  PWM Calculations
      Name                Value  
    ---------           ---------
  Bits of Resolution    13.204
  Gain                  1.060e-04


  s-domain transfer function

               Wp0   Wp2(Wz1 + s)
  H(s) = Kdc X --- X ------------
                s    Wz1(Wp2 + s)

                  1.53e+04   1.26e+05(1.10e+04 + s)
  H(s) = 1.000 X -------- X ----------------------
                     s       1.10e+04(1.26e+05 + s)



  Digital Compensator Coefficients

  Name    Value     Normalized    Q15      Hex
  ----    -----     ----------    ---      ---
  a1      1.228     1.000         32764    0x7FFC
  a2      -0.228    -0.186        -6089    0xE837
  b0      0.568     0.462         15138    0x3B22
  b1      0.059     0.048         1577     0x0629
  b2      -0.508    -0.414        -13561   0xCB07


  z-domain transfer function

         u(z)  B0 + B1z^(-1) + B2z^(-2)
  H(z) = --- = ------------------------
         e(z)  A0 - A1z^(-1) - A2z^(-2)

          (0.568) + (0.059)z^(-1) + (-0.508)z^(-2)
  H(z) = ---------------------------------------------
          1 - (1.228)z^(-1) - (-0.228)z^(-2)
 */

/* Compensator Coefficient Defines */
#define PFCCURRENTCOEFFA1               0x7FFC
#define PFCCURRENTCOEFFA2               0xE837

#define PFCCURRENTCOEFFB0_LL             9083//0x3B22
#define PFCCURRENTCOEFFB1_LL             946//0x0629
#define PFCCURRENTCOEFFB2_LL             -8137//0xCB07

#define PFCCURRENTCOEFFB0_HL             6056           
#define PFCCURRENTCOEFFB1_HL             631    
#define PFCCURRENTCOEFFB2_HL             -5424  

#define PFCCURRENTPOSTSCALER            0x4E9D
#define PFCCURRENTPOSTSHIFT             -1

/*Compensator Coefficient for Low Line / High Power conditions*/
#define PFCCURRENTCOEFFB0               6536
#define PFCCURRENTCOEFFB1               681
#define PFCCURRENTCOEFFB2               -5854


/* Coefficients for 60kHz operation*/
/**
  Compensator Type:  2P2Z
      Entry                Value  
    ---------            ---------
  Pole 0                 2.4397e+03 Hz
  Pole 2                 2.0000e+04 Hz
  Zero 1                 1.7500e+03 Hz
  Gain(Kdc)              1.000
  Warp                   false
  PWM Frequency          6.0000e+04
  PWM Sampling Ratio     1
  Sampling Frequency     6.0000e+04
  PWM Max Resolution     1.0600e-09
  Computational Delay    1.3500e-06
  Gate Drive Delay       1.5000e-07
  Control Output Min.    0
  Control Output Max.    32767
  Kuc Gain               8.4196e+01
  Use Kuc Gain           false


  PWM Calculations
      Name                Value  
    ---------           ---------
  Bits of Resolution    13.941
  Gain                  6.360e-05


  s-domain transfer function

               Wp0   Wp2(Wz1 + s)
  H(s) = Kdc X --- X ------------
                s    Wz1(Wp2 + s)

                  1.53e+04   1.26e+05(1.10e+04 + s)
  H(s) = 1.000 X -------- X ----------------------
                     s       1.10e+04(1.26e+05 + s)



  Digital Compensator Coefficients

  Name    Value     Normalized    Q15      Hex
  ----    -----     ----------    ---      ---
  a1      0.977     0.977         32012    0x7D0C
  a2      0.023     0.023         755      0x02F3
  b0      0.778     0.778         25508    0x63A4
  b1      0.131     0.131         4282     0x10BA
  b2      -0.648    -0.648        -21226   0xAD16


  z-domain transfer function

         u(z)  B0 + B1z^(-1) + B2z^(-2)
  H(z) = --- = ------------------------
         e(z)  A0 - A1z^(-1) - A2z^(-2)

          (0.778) + (0.131)z^(-1) + (-0.648)z^(-2)
  H(z) = ---------------------------------------------
          1 - (0.977)z^(-1) - (0.023)z^(-2)

#define PFCCURRENTCOEFFA1               0x7D0C
#define PFCCURRENTCOEFFA2               0x02F3
#define PFCCURRENTCOEFFB0_1             0x63A4
#define PFCCURRENTCOEFFB1_1             0x10BA
#define PFCCURRENTCOEFFB2_1             0xAD16
#define PFCCURRENTPOSTSCALER            0x7FFF
#define PFCCURRENTPOSTSHIFT             0x0000
#define PFCCURRENTPRESHIFT              0x0000

#define PFCCURRENTCOEFFB0               PFCCURRENTCOEFFB0_1
#define PFCCURRENTCOEFFB1               PFCCURRENTCOEFFB1_1
#define PFCCURRENTCOEFFB2               PFCCURRENTCOEFFB2_1
 * */

/* Compensator Clamp Limits */
#define PFCCURRENTMINCLAMP              -31000
#define PFCOUTPUTCLAMP                  31000     /* max duty clamp for effective reset for the CT*/
#define GATEDRV_DLY                     220       /* Gate Driver Delay 220ns */

/* DCR Drop calculation parameters */
#define RES_DCR                         1000      /* the DCR of the inductor is takes as 30m ohm */
#define DCRDROP_MAX                     1800      /* Max.Value of DCR drop */