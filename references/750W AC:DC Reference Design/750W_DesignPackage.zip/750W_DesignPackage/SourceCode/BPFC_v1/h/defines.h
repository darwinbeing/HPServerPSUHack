/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/
                                
#define ON   1
#define OFF  0
                               
#define ENABLED    1
#define DISABLED   0

// Enable to test basic functionality
#define TESTMODE DISABLED

// Enable code that can show were ADC AN0 is being triggered using PWM4 (pin17 of P1)
#define CURRTRIGPOINT       DISABLED

// LED1 indication options
#define SWITCHOVER          1
#define UARTCRC_GOOD        2
#define POWER_ON            3
#define BOOTLOADER_FUNC     4
#define TRAP                5
#define OVR_CURR            6
#define RMSCURRCALC         7
#define ZEROCROSSDETECT     8
#define BULKVOLTMANAGE      9
#define TRANSIENTMODE       10          /* Adaptive gain control for large load transients */
#define RELAYTURNON         11
#define SOFTSTART           12
#define PEAKDETECT          13          /* Location of Vpeak measurement */


#define LED_DRV1   SWITCHOVER

#define DRV_LED1    LATBbits.LATB4

#define DRV_LED1_BTG() \
        __asm__("BTG LATB, #4");

//Strictly used for fault indication
#define DRV_LED2     LATBbits.LATB8

// Enable/Disable DACOUT feature which is displayed on header pin
#define DACOUT      DISABLED  

#define DCMCORR         1
#define REFCURR         2
#define DUTYFF          3
#define RMSCURRENT      4
#define VINSENSEADC     5
#define VINSENSEFILT    6
#define DUTYCYCLE       7
#define VOLTCOMPOUT     8
#define CALCRMSPOWER    9       /* RMS Power that is calculated every ~1AC cycle */
#define MEASCURR        10      /* Raw ADC results */
#define CURRERROR       11      /* Delta between scaled and refernce current*/
#define BULKVOLTADC     12      /* Raw ADC results */
#define BULKVOLTFILT    13      /* Average of four samples */
#define MEASCURRSCALED  14      /* DCM Correction Factor Applied */
#define VACRMS          15
#define CURRCOMPOUT     16      /* Current compensator output scaled and shifted */

#if (DACOUT == ENABLED)
#define DACFUNCT    REFCURR
#else
#define DRV_IO      LATBbits.LATB3
#define DACFUNCT    DISABLED
#endif

#define FCY  70000000UL              /* Define instruction rate for delay routine */

/* Switching frequecny setting */
#define CONVSWITCHFREQ              100000       /* PWM1 Switching frequency in Hz */

/* PWM Resolution (~1.06 ns) */
#define PWMRESOLUTION                1           /* 1=1.06ns, 2=2.12ns, 3=4.24ns */
                                        
#define F_ACLK                        (unsigned long)(7372800 * 128)             /* 943,718,400 ( = 8 x Auxiliary Clock Frequency) */
#define T_ACLK                        ((float)(1/(float)(F_ACLK/PWMRESOLUTION))) 

/* PWM Period Calculation */
#define PFCPERIOD                     ((unsigned int)(((float)((1/(float)(CONVSWITCHFREQ))/T_ACLK)-1)))   

/* ADC/DAC Resolution Setting*/
#define ADCRESOLUTION                 1241      /* 4096 (2^12)/3.3V */
#define DACRESOLUTION                 1241

/* Input Voltage/Output Voltage /Current Feedback Gains */
#define VACFBGAIN                     0.0070423     /* 10k/(3*470k+10k), Vbase = 468.6V  (Bulk Voltage Divider network)*/
#define VBULKFBGAIN                   0.0070422     /* 10k/(3*470k+10k+20) (Input Voltage Divider network)*/
#define CURRENTFBGAIN                 0.165         /* 1/100 * 16.5, Ibase = 20A (Current transformer and Resistance network */

/* Output Voltage reference settings */
#define BULKREDUCTIONLIMIT            20          /* Bulk voltage reduction during Variable DC link voltage     */  
#define PFCVOLTAGEREF                 400         /* PFC output voltage in volts */

#define PFCVOLTAGEREF_LIGHT_LOAD       (PFCVOLTAGEREF-BULKREDUCTIONLIMIT)     /* PFC output voltage in volts (when variable DC_Link is enabled) */

#define PFCVOLTAGEREFADC               (unsigned int)(VBULKFBGAIN*ADCRESOLUTION*PFCVOLTAGEREF)

#define PFCVOLTAGEREFADC_LIGHT_LOAD    (unsigned int)(VBULKFBGAIN*ADCRESOLUTION*PFCVOLTAGEREF_LIGHT_LOAD)

#define SHIFT_Q15                       3         /* left shift value to mak Q1.15 format */
#define MULSHIFT                        1         /* Shift used in multiplication (mul.ss) */

// DC-DC system states
#define DCDCREGULATIONMODE              0x02
#define DCDCFAULTMODE                   0x08
