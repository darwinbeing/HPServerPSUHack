/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include "p33Exxxx.h"
#include "defines.h"
#include "libpic30.h"
#include "stdint.h"
#include "voltageloop.h"
#include "../ezbl_integration/ezbl.h"

#define ONE_ACCYCLE_DELAY   40                                  /* A delay of 20ms to calculate VRMS */

void initClock(void);                                           /* Clock Initialization */
void initIOPorts(void);                                         /* IO ports initializations ex: relay drv ,MOSFET ON/OFF */
void initPWM(void);                                             /* PWM initialization Redundant Mode */
void initADC(void);                                             /* ADC module initialization */
void initCMP(void);                                             /* Comparator initialization for Debugging and Over Current Protection */
void initTMR(void);                                             /* Initialization of Timer for the system protection */
void initUART(void);                                            /* Initialization of UART */
void disableModules(void);
void initPFCComp(void);                                         /* PFC compensators initialization */

// Bootloader prototype
extern void EZBL_BootloaderInit(void);
extern int EZBL_BootloaderTaskFunc(void);

extern void uartCommFunct(void);

