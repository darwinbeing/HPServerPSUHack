/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include "xc.h"
#include "stdint.h"
#include "voltageLoop.h"
#include "init.h"

/* PFC Soft Start Parameters */
#define SOFTSTARTTIME                      500         /* value in ms */
#define SOFTSTARTCOUNT                     (signed int)(SOFTSTARTTIME/.1667)       /* softstart time (ms) / T3ISR (ms) found in init.h */
#define SOFTSTARTSCALER                    (signed int) ((32767/SOFTSTARTCOUNT)<<10)

/*Input Voltage Limits */
#define INPUTUNDERVOLTAGE                   80      /* Under Voltage threshold in volts */
#define INPUTUNDERVOLTAGEADC                (int)(INPUTUNDERVOLTAGE*VACFBGAIN*ADCRESOLUTION)

#define INPUTOVERVOLTAGE                    269      /* Over Voltage threshold in volts */
#define INPUTOVERVOLTAGEADC                 (int)(INPUTOVERVOLTAGE*VACFBGAIN*ADCRESOLUTION)

#define INPUTVOLTAGEHYST                    3     /* Hysteresis in volts */
#define INPUTVOLTAGEHYSTADC                 (int)(INPUTVOLTAGEHYST*VACFBGAIN*ADCRESOLUTION)

#define INPUTVOLTMINHYST                    (INPUTUNDERVOLTAGEADC + INPUTVOLTAGEHYSTADC)
#define INPUTVOLTMAXHYST                    (INPUTOVERVOLTAGEADC - INPUTVOLTAGEHYSTADC)

/* Output Voltage Limits */
#define VOUTMAXHYST                        35
#define VOUTMINHYST                        100
#define PFCVOUTMAX                         (PFCVOLTAGEREF + VOUTMAXHYST)                                 
#define PFCVOUTMAXADC                      (unsigned int)(VBULKFBGAIN*ADCRESOLUTION*PFCVOUTMAX)
#define PFCVOUTMIN                         (PFCVOLTAGEREF - VOUTMINHYST)                                 
#define PFCVOUTMINADC                      (unsigned int)(VBULKFBGAIN*ADCRESOLUTION*PFCVOUTMIN)

#define MUL_FACTOR                          8
#define VDIFF                               8        /* Input voltage difference for the relay turn-on */
#define VDIFF_ADC                           (int)(VDIFF*VBULKFBGAIN*ADCRESOLUTION*MUL_FACTOR)
#define NCPTURNONVOLTAGE                    105      /* Relay Turn on voltage */
#define NCPTURNONVOLTAGE_ADC                (int)(VBULKFBGAIN*ADCRESOLUTION*NCPTURNONVOLTAGE)

/* LED blinking counts for the Faults 1-reserved for startup indication */
#define FAULT_OVERCURRENT                    2                  /* LED blink counts for Over current protection          */
#define FAULT_INPUTUNDERVOLTAGE              3                  /* LED blink counts for Input under voltage protection   */
#define FAULT_INPUTOVERVOLTAGE               4                  /* LED blink counts for input over voltage protection    */
#define FAULT_OUTPUTUNDERVOLTAGE             5                  /* LED blink counts for output under voltage protection  */
#define FAULT_OUTPUTOVERVOLTAGE              6                  /* LED blink counts for output over voltage protection   */
#define FAULT_UARTCOMM                       7                  /* LED Blink counts for UART communication failure       */
#define FAULT_DC2DC                          8                  /* LED Blink counts for DC-DC failure                    */
#define FAULT_MAINS_FREQUENCY                9                  /* LED Blink counts for Input mains frequency protection */
#define FAULT_DRIVERSUPPLY                   10                 /* LED Blink counts for 13V driver supply protection     */
#define FAULT_OVERPOWER                      11                 /* LED Blink counts for over power when < 110Vac         */

/* Fault Counter Limits and LED blinking time and delay between the blinks*/
#define FREQUENCYLIMIT62HZ                  110//228                     /* Frequency limit corresponding to 63Hz */
#define FREQUENCYLIMIT45HZ                  160//319                     /* Frequency limit corresponding to 45Hz */
#define FREQUENCYFAULTCOUNTLIMIT            5                       /* Mains Frequency fault counter */
#define DRVSUPPLYFAULTCOUNT                 10                      /* 13V driver Fault Counter limit 10*20u = 200u*/
#define FAULTCOUNTLIMIT                     6                       /* Fault Counter for input Voltage 3-cycles*/
#define FAULTCOUNTLIMIT_CURRENT             10                      /* Fault Counter */
#define LED_TOGGLE_TIME                     2000                    /* LED on period */
#define LED_TOGGLE_DELAY                    8000                    /* Delay between toggles */

static inline void SoftStart(void);                                        /* Soft Start routine in ramp manner */
static inline void Fault_Monitor(void);                                    /* Reset of the variables during the Fault Mode */
static inline void FaultLED_Indicator(void);                               /* LED blinking function during the Fault Mode */
static inline void RelayControl(void);                                     /* Relay inrush control to bypass the NTC */


