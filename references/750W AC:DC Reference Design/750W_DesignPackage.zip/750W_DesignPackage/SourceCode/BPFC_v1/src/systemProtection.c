/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include <p33Exxxx.h>

#include "systemProtection.h"

uint16_t inputVoltageGoodCnt = 0;

/*******************************************************************************
ISR: Over Current Protection
*******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _CMP1Interrupt()
{
#if (LED_DRV1 == OVR_CURR)
    DRV_LED1_BTG();
#endif
  
    if(++overCurrentFaultCounter >= FAULTCOUNTLIMIT_CURRENT)                                
    {
        IOCON1 = (IOCON1 & 0xFC3F) | 0x0300; // Don't wait to disable PWMs
        pfcFaultFlags.OverCurrent = ENABLED;              
        if(faultState == DISABLED)
        faultState = FAULT_OVERCURRENT;     
    }
    
    _AC1IF = DISABLED;                                  
}

/*******************************************************************************
ISR:            TMR3Interrupt
Description:	Interrupt System Faults, Fault monitoring, Fault LED blinking
*******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T3Interrupt()
{
    if(pfcFaultFlags.SystemFaults)
    {   
        Fault_Monitor();                                       
        
        if(timerInterruptCounter) 
          timerInterruptCounter--;  
        else {
            FaultLED_Indicator();                                  
        } 
    }     
    else if(pfcStateFlags.StartUp == ENABLED)                     
    {
       faultState = DISABLED;
       DRV_LED2 = OFF;
       faultLEDToggleCounter = DISABLED;
       timerInterruptCounter = DISABLED;
       
       // Remove the overrides
       IOCON1 &= 0xFC3F;
        
       CLR_VOLTAGEHISTORY();                                    
       CLR_CURRENTHISTORY();
       pfcStateFlags.SyncZeroCross = ENABLED;                
       pfcStateFlags.StartUp = DISABLED;                                           
    }

    
    /***********************System SoftStart Mode Operation *******************/
    if(pfcStateFlags.SoftStartActive == ENABLED)
    {
        SoftStart();   
    }

    // Only check faults when system enters regulation mode
    if(pfcStateFlags.RegulationMode == ENABLED)
    {
/*******************************************************************************
Functionality: Output Under Voltage Fault
Description: When output voltage < 300V, system will enter in Fault mode
*******************************************************************************/
        if(pfcBulkVoltageFiltered < PFCVOUTMINADC)
        {                                
            if(++outputUnderVoltageFaultCounter >= FAULTCOUNTLIMIT)             
            {
                pfcFaultFlags.OutputUnderVoltage = ENABLED;
                if(faultState == DISABLED)
                faultState = FAULT_OUTPUTUNDERVOLTAGE;
            }
        }
        else {
            outputUnderVoltageFaultCounter = DISABLED;                          
        }

/*******************************************************************************
Functionality: Output Over Voltage Fault
Description: When output voltage > 430V, system will enter in Fault mode
*******************************************************************************/   
        if(pfcBulkVoltageFiltered > PFCVOUTMAXADC)
        {                                   
            if(++outputOverVoltageFaultCounter >= FAULTCOUNTLIMIT)                                              
            {
                pfcFaultFlags.OutputOverVoltage = ENABLED;
                if(faultState == DISABLED)
                faultState = FAULT_OUTPUTOVERVOLTAGE;
            }                       
        }
        else {
             outputOverVoltageFaultCounter = DISABLED;
        }
        
/*******************************************************************************
Functionality: Input under/over Voltage Fault
Description: When input voltage < 88V or > 265V, system will enter in Fault mode
*******************************************************************************/    
        if(pfcStateFlags.NewInputRMS == ENABLED)
        {    
            if(vacRMS < INPUTUNDERVOLTAGEADC)
            {                                      
                if(++inputUnderVoltageFaultCounter >= FAULTCOUNTLIMIT)                                              
                {
                    pfcFaultFlags.MainsUnderVoltage = ENABLED;  
                    if(faultState == DISABLED)
                    faultState = FAULT_INPUTUNDERVOLTAGE;
                } 
            }
            else { 
                inputUnderVoltageFaultCounter = DISABLED;                         
            }

            if(vacRMS > INPUTOVERVOLTAGEADC)
            {                                  
                if(++inputOverVoltageFaultCounter >= FAULTCOUNTLIMIT)
                {
                    pfcFaultFlags.MainsOverVoltage = ENABLED; 
                    if(faultState == DISABLED)
                    faultState = FAULT_INPUTOVERVOLTAGE;
                }
            }
            else {
                inputOverVoltageFaultCounter = DISABLED;                           
            }
        }
               
/*********************End If statement ****************************************/    
    }        
    else {
        /* Reset Fault Counters*/
       outputUnderVoltageFaultCounter = DISABLED;                               
       outputOverVoltageFaultCounter = DISABLED;
       inputUnderVoltageFaultCounter = DISABLED;
       inputOverVoltageFaultCounter = DISABLED;
    }
        
        
/*******************************************************************************
Function: ACLine_Frequency_Check
Description:  Lockout is 44Hz or 63Hz and enters into operation at 45Hz to 62HZ
*******************************************************************************/
    if(halfCycleCounts)
    {
        #if (VARFREQ_ZEROCROSS == ENABLED)
            scaledFreqValue = (__builtin_mulss(halfCycleCounts, PFCPERIOD) >> 15);
        #else
            scaledFreqValue = (__builtin_mulss(halfCycleCounts, PTPER) >> 15);
        #endif 
            
        if((scaledFreqValue < FREQUENCYLIMIT62HZ) || (scaledFreqValue > FREQUENCYLIMIT45HZ))
        {
            if(++mainsFrequencyFaultCounter >= FREQUENCYFAULTCOUNTLIMIT)
            {
                pfcFaultFlags.MainsFreq = ENABLED;
                if(faultState == DISABLED)
                faultState = FAULT_MAINS_FREQUENCY;
            }
        }
        else {
            mainsFrequencyFaultCounter = DISABLED;
        }
        
        halfCycleCounts = 0;
    }

/*******************************************************************************
Functionality: Fault indication for communication Failure
Description: UART_comm.c will flag failure when CRC doesnt match 
*******************************************************************************/    
    if(pfcFaultFlags.Communication == ENABLED)
    {
        if(faultState == DISABLED)
        faultState = FAULT_UARTCOMM;
    }    
    
/*******************************************************************************
Functionality: Fault indication for DC-DC Failure
Description: UART_comm.c will flag failure when data received for secondary 
*******************************************************************************/    
    if(pfcFaultFlags.DCDCFaultMode == ENABLED)
    {
        if(faultState == DISABLED)
        faultState = FAULT_DC2DC;
    }    
    
/*******************************************************************************
Functionality: Fault indication for OVER Power @ low AC line
Description: Error will be flagged when RMS power calculated in voltageloop.c 
*******************************************************************************/    
    if(pfcFaultFlags.LowLineOverPower == ENABLED)
    {    
        if(faultState == DISABLED)
          faultState = FAULT_OVERPOWER;  
    }
    
/*******************************************************************************
Functionality: Mains Input voltage checking used at startup
Description: Whenever the input voltage greater than 82V and less than 268V, the 
             system will enter into Soft start mode
*******************************************************************************/
    if((pfcStateFlags.NewInputRMS == ENABLED) && (pfcStateFlags.StartUp == ENABLED))
    {    
        if((vacRMS < INPUTVOLTMAXHYST) && (vacRMS > INPUTVOLTMINHYST))                 
        {  
            if(++inputVoltageGoodCnt >= 10) {   
                pfcFaultFlags.MainsVoltage = DISABLED;                            
            }
        }
        else {
            inputVoltageGoodCnt = 0;
        }
    }

    
    pfcStateFlags.NewInputRMS = DISABLED;
    
    // If fault on PFC side let DC-DC know as there are cases were the DC-DC
    // could remain active
    pfcFaultFlags.ShutDownDCDC = (faultState) ? ENABLED : DISABLED;
    
    IFS0bits.T3IF = DISABLED;                                                  
}
/*******************************************************************************
End of ISR
*******************************************************************************/

/*******************************************************************************
Function: 		FaultLED Indication
Description:	When in fault mode, LED will blink based on FaultState
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) FaultLED_Indicator(void)
{
    switch(faultLEDState)
    {
        case 0:
            DRV_LED2 = ON;
            #if(LED_DRV1 == POWER_ON)
            DRV_LED1 = ON;
            #endif
            timerInterruptCounter = LED_TOGGLE_TIME;
            faultLEDState++;
        break;
        case 1:
            DRV_LED2 = OFF;
            #if(LED_DRV1 == POWER_ON)
            DRV_LED1 = OFF;
            #endif
            timerInterruptCounter = LED_TOGGLE_TIME;
            faultLEDState++;
        break;
        case 2:
            if(++faultLEDToggleCounter >= faultState)
            {
                timerInterruptCounter = LED_TOGGLE_DELAY;
                faultLEDToggleCounter = 0;
            }
            else {
                timerInterruptCounter = 0;
            }
            
            faultLEDState = 0;
            
        break;

        default:
        break;

    }
    
}
/*******************************************************************************
Function: 		Fault Monitor
Description:	When in fault mode, Override PWMs and Disable the regulation mode
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) Fault_Monitor(void)
{
    pfcStateFlags.RegulationMode = DISABLED ;
    
    PDC1                         = DISABLED ;                             
    IOCON1 = (IOCON1 & 0xFC3F) | 0x0300; //Override data 0b00, OVRENH/L - 1
                                 
    pfcVoltCompOutput            = DISABLED ;                             
    currentControlOutput         = DISABLED ;
    dutyFeedForward              = DISABLED ;
    dcr_Drop                     = DISABLED ;
    pfcCurrentRef                = DISABLED ;
    pfcVoltageRef                = DISABLED ;
    pfcCurrent                   = DISABLED ;
    pfcCurrCompOutput            = DISABLED ;
 
    RelayControl();              /* Inrush Relay control */
}
/*******************************************************************************
End of ISR
*******************************************************************************/

/*******************************************************************************
ISR:            ADCMP1Interrupt
Description:	Interrupt for auxiliary drive voltage management
*******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _ADCMP1Interrupt()
{    
    int dummy;
    
    dummy = ADCMP1CONbits.CHNL;     /* Clears logic so not to enter multiple times */
    
    if(++drvSupplyFaultCounter >= DRVSUPPLYFAULTCOUNT)
    {
        pfcFaultFlags.DrvSupply = ENABLED;
        
        if(faultState == DISABLED) 
        faultState = FAULT_DRIVERSUPPLY;
       
        drvSupplyFaultCounter   = DISABLED;
    }

    _ADCMP1IF = DISABLED;
} 
/*******************************************************************************
Function: 		Relay Control
Description:	Output voltage > 108V (NCP turn-on Voltage) 
                and Output Bulk voltage is equal to peak of the sine wave 
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) RelayControl(void)
{
   int16_t diffVoltage;
    
   diffVoltage = outputBulkVoltage-vacPeak;    
   
   if((diffVoltage <= VDIFF_ADC) && (pfcBulkVoltageFiltered >= NCPTURNONVOLTAGE_ADC) && (pfcFaultFlags.DrvSupply == DISABLED))
   { 
        #if(LED_DRV1 == RELAYTURNON)
           DRV_LED1 = ON;
        #endif
             
       IOCON2bits.OVRDAT = 0b01; 
   }
}

/*******************************************************************************
Function: 		SoftStart
Description:	Converter SoftStart (SystemState-1)
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) SoftStart(void)
{
    if(sftStrtInitVoltage == DISABLED)
    {
        sftStrtInitVoltage            = pfcBulkVoltageFiltered;                    /* Initial voltage for the soft start */
        sftStrtVoltageDelta           = PFCVOLTAGEREFADC - pfcBulkVoltageFiltered; /* Soft Start Delta voltage */                                                                               
        #if(LED_DRV1 == SOFTSTART)
            DRV_LED1 = ON;
        #endif    
    }

    sftStrtScaler = (__builtin_mulss(SOFTSTARTSCALER, sftStartTimer) >> 10);                           /* Soft start scaling factor  (Q6.10*Q1.15/Q6.10 = Q1.15 */
    pfcVoltageRef = sftStrtInitVoltage + (__builtin_mulss(sftStrtVoltageDelta, sftStrtScaler) >> 15);  /* Ramping up the Voltage to 400V */

    if((pfcVoltageRef >= PFCVOLTAGEREFADC) || (pfcBulkVoltageFiltered >= PFCVOLTAGEREFADC))
    {         
       pfcVoltageRef                 = PFCVOLTAGEREFADC;                       /* Vref = 400V soft start is completed */
       pfcStateFlags.SoftStartActive = DISABLED;                              
       pfcStateFlags.RegulationMode  = ENABLED;                                
   
        #if(LED_DRV1 == SOFTSTART)
            DRV_LED1 = OFF;
        #endif 
    }    
    ++sftStartTimer ;                                                           
    
}
