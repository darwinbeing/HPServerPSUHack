/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include "uart_comm.h"


// Transmit buffers for IC-IC communication
uint16_t tx_buffer[TX_BUF_LEN+1]; 
EZBL_FIFO UART_TxFifoFB;
uint8_t UART_TxFifoBufferFB[TX_MAX_BUF_PTR];

// Receive Buffers for IC-IC communications
uint16_t rx_buffer[RX_BUF_LEN+1]; 
EZBL_FIFO UART_RxFifoFB;
uint8_t UART_RxFifoBufferFB[RX_MAX_BUF_PTR*2];

// File scope variables
static uint16_t cntT5ISR;
static uint8_t CRCIncorrectCnt = 0, receivedDataCnt = 0;

uint16_t avgCurrentFB = 0, systemFaultsFB = 0;

// External global variables
extern volatile PFC_FAULTS pfcFaultFlags;
extern volatile PFC_FLAGS  pfcStateFlags;
extern uint16_t pfcBulkVoltageFiltered, vacRMS;
extern int16_t rmsPower;


void uartCommFunct(void)
{
    // Reset Fifo and setup pointers 
    EZBL_FIFOReset(&UART_TxFifoFB, UART_TxFifoBufferFB, sizeof(UART_TxFifoBufferFB), 0, 0);
    EZBL_FIFOReset(&UART_RxFifoFB, UART_RxFifoBufferFB, sizeof(UART_RxFifoBufferFB), 0, 0);
    
    UART1_FIFO_EnableInterrupts();
    
    T5CONbits.TON = 1;
}

void __attribute__ ((__interrupt__, no_auto_psv)) _T5Interrupt()
{
    uint16_t resultCRC;
    
    if(++cntT5ISR >= 2u)
    {    
        cntT5ISR = 0;
        // Load data to be sent to DC-DC controller
        tx_buffer[0] = pfcStateFlags.SystemState;
        tx_buffer[1] = pfcFaultFlags.SystemFaults;
        tx_buffer[2] = pfcBulkVoltageFiltered;
        tx_buffer[3] = vacRMS;
        tx_buffer[4] = rmsPower;
        tx_buffer[5] = 0xA5A5;
    
        // Perform CRC on data to be transmitted, sufficient to take 2 of 4 bytes
        resultCRC = EZBL_CRC32(CRC_START, &tx_buffer[0], 2*TX_BUF_LEN);
        tx_buffer[TX_BUF_LEN] = resultCRC;
        
        EZBL_RAMCopy(&UART_TxFifoBufferFB, &tx_buffer[0], TX_MAX_BUF_PTR);
        
        // Reset dataCount and tailPtr if fifo was emptied from last call
        if(UART_TxFifoFB.dataCount == 0u)
        {    
            UART_TxFifoFB.tailPtr = &UART_TxFifoBufferFB[0];
            UART_TxFifoFB.dataCount = TX_MAX_BUF_PTR;
           
            _U1TXIF = 1;
        }
    }
    
    // If we don't receive any UART data from DC-DC for extended time - fault
    if((UART_RxFifoFB.dataCount < RX_MAX_BUF_PTR) && (pfcStateFlags.RegulationMode == ENABLED))
    {
        if(++receivedDataCnt > 40)
        pfcFaultFlags.Communication = ENABLED;
    }    
    else {
        receivedDataCnt = 0;
    }
    
    // If data available in RX FIFO, call CRC and if valid move data to appropriate variables
    while(UART_RxFifoFB.dataCount >= RX_MAX_BUF_PTR)
    {
        EZBL_FIFOPeek(&rx_buffer[0], &UART_RxFifoFB, RX_MAX_BUF_PTR);
        
        resultCRC = EZBL_CRC32(CRC_START, &rx_buffer[0], 2*RX_BUF_LEN);
                       
        // Check CRC result
        if(resultCRC == rx_buffer[RX_BUF_LEN])
        {
            EZBL_FIFORead(0, &UART_RxFifoFB, RX_MAX_BUF_PTR);  // Throw away good peeked data
            
            #if (LED_DRV1 == UARTCRC_GOOD)
            DRV_LED1_BTG();     // Toggle each time CRC checks out
            #endif                        
            
            CRCIncorrectCnt = 0;
            
            // Move data to variables 
            if(rx_buffer[0] == DCDCREGULATIONMODE)
                pfcStateFlags.DCDCRegulationMode = ENABLED;
            else if ((rx_buffer[0] == DCDCFAULTMODE) && (pfcStateFlags.RegulationMode == ENABLED))
                pfcFaultFlags.DCDCFaultMode = ENABLED;
        
            avgCurrentFB = rx_buffer[1];
            systemFaultsFB = rx_buffer[2]; 
        }
        else   // CRC check failed, try eating a byte to resynchronize and try again computing a CRC
        {
            EZBL_FIFORead(0, &UART_RxFifoFB, 1);   

            if (pfcStateFlags.RegulationMode == ENABLED)
            {    
                if(++CRCIncorrectCnt > CRCFAULTCNT)
                    pfcFaultFlags.Communication = ENABLED;
            }    
        }    
       
    }    
  
    _T5IF = 0;
}


