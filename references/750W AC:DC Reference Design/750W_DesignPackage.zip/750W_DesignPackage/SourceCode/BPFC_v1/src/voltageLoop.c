/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include "voltageLoop.h"

volatile PFC_FAULTS pfcFaultFlags;
volatile PFC_FLAGS  pfcStateFlags;

extern volatile uint16_t __attribute__((near)) criticalISRDone;

static inline void DCM_CCM_SampleCorrection(void);                         /* DCM sample correction factor function */
static inline void Duty_Feedforward(void);                                 /* Duty feed forward calculation  to improve PF and THD */
static inline void Current_Reference_Calculation(void);                    /* Current reference calculation based on voltage loop compensator */
static inline void VRMS_Calculation(void) ;                                /* VRMS calculation  */
static inline void Voltage_Compensator(void);                              /* Voltage Loop compensator function */
static inline void Positive_AC_Cycle(void);                                /* Positive AC cycle functions */
static inline void Negative_AC_Cycle(void);                                /* Negative AC cycle functions */
static inline void RMSCurrent_Calculation(void);                           /* VRMS calculation */
static inline void System_Voltages(void);                                  /* All voltage measurements */
static inline void BulkVoltageManagement(void);                            /* Output voltage reductions/Increments */
static inline void Dynamic_Gain_Adjustment(void);                          /* Dynamic gain adjustment to improve the transient response */
static inline void FETON(void);                                            /* Parallel MOSFET turn ON/OFF to improve the efficiency */


static uint16_t overridePWMCnt = 0;
static int16_t  currentOffset = 0;
static uint8_t overPowerCnt = 0, vacScalerDCM = 0;
/*******************************************************************************
ISR: 		ADCAN3Interrupt
Description:	Interrupt for Input/Output Voltage averaging and fault detection,
                Peak input detection, RMS Calculation, and Current ref calculation
*******************************************************************************/
void __attribute__((__interrupt__,__shadow__,no_auto_psv)) _ADCAN3Interrupt()
{
#if (DACOUT == DISABLED) 
    DRV_IO = ENABLED;
#endif
   
   ADCON3Lbits.SWCTRG = ENABLED;         /* SW trigger for Aux supply */
   System_Voltages();                    /* System Voltage readings (12bit Resolution) */
   RMSCurrent_Calculation();   
   
   /* Determine active phase and if zero cross event   */  
    if(vacLine > vacNeutral)                                          
    {
        Positive_AC_Cycle();   /* Line active routine */
    }
    else {
        Negative_AC_Cycle();   /* Neutral active routine */ 
    }
   
    // vacFiltered is set after calling one of the above functions 
    #if ((DACOUT == ENABLED) && (DACFUNCT == VINSENSEFILT))
        CMP3DAC = vacFiltered >> 3;
    #endif 
   
    // Frequency check counter
    if((++freqCount >= FREQUENCYCOUNT_FILTER) && (pfcStateFlags.ZeroCrossDetect == ENABLED))
    {
        halfCycleCounts = freqCount;
        freqCount = DISABLED;
    }
        
    // These functions rely on AC filtered data so called after reading system voltages
    if(pfcFaultFlags.MainsVoltage == DISABLED)
    {    
        Current_Reference_Calculation();          /* Current reference calculation */
        Duty_Feedforward();                       /* Duty feed forward calculation  */
        DCM_CCM_SampleCorrection();               /* DCM Sample Correction  */
            
        pfcStateFlags.ZeroCrossDetect = DISABLED;  /* Routines below do not need ZC information */    
    }   
 
    ++isrCnt;
    if((isrCnt&3) == DISABLED)                                         
    {
        VRMS_Calculation();                                                
        Voltage_Compensator();
        
        if(pfcStateFlags.RegulationMode == ENABLED) // Adaptive algorithms applied after startup completes
        {
            Dynamic_Gain_Adjustment();                                            
            //BulkVoltageManagement();                       /* Bulk Voltage reduction/Increment */
            FETON();                                         /* Parallel MOSFET turn ON/OFF */         
        }
        criticalISRDone = 1;                                 /* Force variable to 1 (bit 0), bit 1 set by PFC current loop but order matters, when = 3 swap partitions */
        pfcStateFlags.NewRMSPower = DISABLED;                /* Clear flags now that all functions in this ISR had a chance to act on it */
    }
    
    IFS7bits.ADCAN3IF = DISABLED ;                           /* Clear Interrupt Flag */

#if(DACOUT == DISABLED)  
    DRV_IO = DISABLED;
#endif
}
/*******************************************************************************
End of ISR
*******************************************************************************/

/*******************************************************************************
Function: DCM Sample Correction Factor
Description: Sample correction factor = PIoutput*Vdc/(Vdc-Vin)
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) DCM_CCM_SampleCorrection(void)
{
    int16_t deltaV; 
    uint32_t numDCMCorrFact;
    
    deltaV = outputBulkVoltage - vacFiltered;
    
    if((deltaV > 0) && (rmsPower < 1200)) //Applied below 350W
    { 
        numDCMCorrFact = __builtin_mulss(outputBulkVoltage, currentControlOutput);
        dcmCorrFactor  = __builtin_divud(numDCMCorrFact, deltaV); 

        if(dcmCorrFactor > MAXLIMITQ15) 
            dcmCorrFactor = MAXLIMITQ15;
        else if(dcmCorrFactor < (25000 >> vacScalerDCM))        // Lower limit threshold factor of 2 between high/low lines
            dcmCorrFactor = (25000 >> vacScalerDCM);
    
        if (pfcStateFlags.TransientMode == ENABLED)
            dcmCorrFactor = MAXLIMITQ15;        
    }
	else {
		dcmCorrFactor = MAXLIMITQ15;
	}    
           
    #if ((DACOUT == ENABLED) && (DACFUNCT == DCMCORR))
        CMP3DAC = dcmCorrFactor >> 3;
    #endif
    
    #if ((DACOUT == ENABLED) && (DACFUNCT == DUTYCYCLE))
        CMP3DAC = currentControlOutput >> 3;
    #endif        
}
/*******************************************************************************
Function: Duty_Feedforward
Description: Duty cycle = Output Voltage/(Output voltage-Input voltage)
D =Vdc/(Vdc-Vin) = [1-(Vin/Vdc)] >> 1 scaled
 
****************************************************************************** */
static inline void __attribute__((always_inline, optimize(1))) Duty_Feedforward(void)
{
    dutyFeedForward = MAXLIMITQ14 - (__builtin_divsd(((long)vacFiltered << 14), outputBulkVoltage));   /* Q14 - Q29/Q15 = Q14 */
   
    #if ((DACOUT == ENABLED) && (DACFUNCT == DUTYFF))
        CMP3DAC = dutyFeedForward >> 2;
    #endif 
}

/******************************************************************************* 
Function: Current_Reference_Calculation
Description: This function calculates the Current reference based on Voltage compensator output
 * Current Reference = VoltagePIOuptut *CurrScaler
 * FeedForward Correction is constant at light loads and increases linearly and then constant towards the half load and Full load
 * FeedForward Correction and The current reference offset is varied to get Good THD and PF at all loading conditions 
 * 
****************************************************************************** */
static inline void __attribute__((always_inline, optimize(1))) Current_Reference_Calculation(void)
{   
    uint16_t currRefScaler;
           
    #if ((DACOUT == ENABLED) && (DACFUNCT == VOLTCOMPOUT))   
        CMP3DAC = pfcVoltCompOutput >> 3;
    #endif
    
    if((vacRMS < INPUTVOLTAGEHIGHLINEADC) && (pfcStateFlags.ZeroCrossDetect == ENABLED))
    {   
        if(rmsPower > 740) // 200W output power    
        {
            pfcCurrentABCoefficients[0] = PFCCURRENTCOEFFB0;
            pfcCurrentABCoefficients[1] = PFCCURRENTCOEFFB1;
            pfcCurrentABCoefficients[2] = PFCCURRENTCOEFFB2; 
            currentOffset = CURRENT_OFFSET_100PC;  
        }
        else {
           pfcCurrentABCoefficients[0] = PFCCURRENTCOEFFB0_LL;
           pfcCurrentABCoefficients[1] = PFCCURRENTCOEFFB1_LL;
           pfcCurrentABCoefficients[2] = PFCCURRENTCOEFFB2_LL;
           currentOffset = (__builtin_mulss(rmsPower, 18725) >> 15) + 150;
        }
    }    
    else if (pfcStateFlags.ZeroCrossDetect == ENABLED) // For high line and only change at AC zero cross
    {   
        /* If coefficients changed because of high line/low line threshold, need to revert back */
        if (pfcCurrentABCoefficients[0] != PFCCURRENTCOEFFB0_HL)
        {    
            pfcCurrentABCoefficients[0] = PFCCURRENTCOEFFB0_HL;
            pfcCurrentABCoefficients[1] = PFCCURRENTCOEFFB1_HL;
            pfcCurrentABCoefficients[2] = PFCCURRENTCOEFFB2_HL;
        }
        
        if (rmsPower < 940)
        {
            currentOffset = (__builtin_mulss(rmsPower, -5229) >> 15) - 50;
        }
        else
        {           
            currentOffset = (__builtin_mulss(rmsPower, 29228) >> 15) - 1038;
            if(currentOffset > 300)
                currentOffset = 300;
        }   
    }
        
    currRefScaler =__builtin_divsd(((long)vacFiltered << 13), denCurrRefCalc);                             /* CurrRefScaler = Vac /Vrms^2 worst case (3.13*3.13/5.11 = 1.15)  */
    if(currRefScaler >= MAXLIMITQ15)                                                                       /* Saturation limits */
        currRefScaler = MAXLIMITQ15; 

    pfcCurrentRef = (__builtin_mulss(currRefScaler, pfcVoltCompOutput) >> 15) - currentOffset;    /*Current reference calculation */ 
    if(pfcCurrentRef < 0)
       pfcCurrentRef = 0;
   
    #if ((DACOUT == ENABLED) && (DACFUNCT == REFCURR))    
        CMP3DAC = pfcCurrentRef >> 3;
    #endif   
}
/*******************************************************************************
Function: VRMS Calculation
Description:  Vac Peak voltage is detected first and VRMS is calculated there after 
*******************************************************************************/

static inline void __attribute__((always_inline, optimize(1))) VRMS_Calculation(void)
{                    
    /* Find the Peak input voltage to calculate the RMS voltage */
    if((vacFiltered > vacFilteredMax) && (peakDetectFlag == ENABLED))           
    {
        vacFilteredMax = vacFiltered;       
    }
    
    if(vacFiltered > prevVacFiltered)
    {
        downCounter = DISABLED;
        if((++upCounter >= VRMS_COUNT_LIMIT ) && (peakDetectFlag == DISABLED))  
        {
            peakDetectFlag = ENABLED; 
        }
    }
    else {
        upCounter = DISABLED;
        if((++downCounter >= VRMS_COUNT_LIMIT) && (peakDetectFlag == ENABLED))
        {
            #if (LED_DRV1 == PEAKDETECT) 
                DRV_LED1_BTG();
            #endif 

            peakDetectFlag      = DISABLED ;                                  /* Disable Peak detect flag On the down cycle  */ 
            vacPeak             = vacFilteredMax;                                   
            denCurrRefCalc      = (__builtin_mulss(vacPeak,vacPeak) >> 15) ;  /* Den = Vpk*Vpk = (1.15*1.15/1.15) = 1.15 */
            vacRMS              = (__builtin_mulss(vacPeak,VPK2VRMS) >> 18);  /* VRMS calculation Vpeak(Q1.15) *0.7071 (Q1.15) shifted by 15+3 12-bit*/    
            vacFilteredMax      = DISABLED;         

            vacScalerDCM = (vacRMS < INPUTVOLTAGEHIGHLINEADC) ? DISABLED : ENABLED;     /* Set DCM correction scaler based on Vac */
            
            if(pfcStateFlags.RegulationMode == ENABLED)
            {   
                // Equation to set the peak current threshold for given input voltage
                // CMPDAC = -1.25x + 4983
                CMP1DAC = 4983 - (__builtin_mulss(vacRMS, 20480) >> 14);
                if(vacRMS < INPUTVOLTAGEADC)
                    CMP1DAC = 4000;
            }
            
            #if ((DACOUT == ENABLED) && (DACFUNCT == VACRMS))    
                CMP3DAC = vacRMS;
            #endif 
                                              
            pfcStateFlags.NewInputRMS = ENABLED;
        }
    }
    
    prevVacFiltered = vacFiltered;                                              /* storing the Vac filtered value */    
}
/*******************************************************************************
Function: Voltage_Compensator
Description: The compensator runs @12.5kHz. 
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) Voltage_Compensator(void)
{
    INTCON2bits.GIE = DISABLED;                                     /* Disable all Interrupts */
    Nop();Nop();                                                    /* Delay to flush */
    __asm__("CTXTSWP #0x2");                                        /* Swap to Alternate W-Reg #2      */  
    SMPS_Controller2P2ZUpdate_HW_Accel();                           /* 2P2Z compensator (Voltage Loop Compensator)    */
    __asm__("CTXTSWP #0x0");                                        /* Swap back to main register set */ 
    
    INTCON2bits.GIE = ENABLED;                                      /* Enable Interrupts */
}
/*******************************************************************************
Function: Line_Active
Description: The PWM configurations and voltage and Current Loop history restoration and AC cycle skipping 
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) Positive_AC_Cycle(void)
{
    vacFiltered = (vacLine << SHIFT_Q15);                      
    
     // Zero Cross found clear variables, and if required sync startup
    if ((pfcStateFlags.LineActive == DISABLED) && (pfcFaultFlags.SystemFaults == DISABLED))
    {
        #if (LED_DRV1 == ZEROCROSSDETECT) 
            DRV_LED1_BTG();
        #endif 

        /* Force somewhat consecutive faults to occur with AC cycle for driver fault 
           w/ Dig comparator along with comparator over current faults*/
        drvSupplyFaultCounter   = DISABLED; 
        overCurrentFaultCounter = DISABLED;
                     
        // Only needed for startup. Want to synchronize to a ZC event
        if (pfcStateFlags.SyncZeroCross == ENABLED)
        {   
            pfcStateFlags.SoftStartActive = ENABLED; 
            pfcStateFlags.SyncZeroCross  = DISABLED;            
        }       
    
        pfcStateFlags.ZeroCrossDetect = ENABLED;
    }
    pfcStateFlags.LineActive = ENABLED;
}
/*******************************************************************************
Function: Line is not active
Description: PWM configuration, AC cycle skipping  and Voltage and Current Loop Compensators
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) Negative_AC_Cycle(void)
{
    vacFiltered = (vacNeutral << SHIFT_Q15);                          
    
    if ((pfcStateFlags.LineActive == ENABLED) && (pfcFaultFlags.SystemFaults == DISABLED))
    {
        // Zero Cross found
        #if (LED_DRV1 == ZEROCROSSDETECT)
            DRV_LED1_BTG();
        #endif
        
        /* Force somewhat consecutive faults to occur with AC cycle for driver fault 
        w/ Dig comparator along with comparator over current faults*/
        drvSupplyFaultCounter   = DISABLED; 
        overCurrentFaultCounter = DISABLED;
        
        pfcStateFlags.ZeroCrossDetect = ENABLED;
    }
                                     
    pfcStateFlags.LineActive = DISABLED ;
}
/*******************************************************************************
Function: Average Current Calculation
Description: used to calculate the RMS power 
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) RMSCurrent_Calculation(void)
{
    int16_t avgPFCCurrent;
    
    pfcCurrentsum += pfcCurrent;                      /* Add PFC current to PFC current sum */  
    
    if(++avgCurrCounter >= 512)
    {
        avgPFCCurrent = (int)(pfcCurrentsum >> 9);
        avgCurrCounter = 0;
        pfcCurrentsum = 0; 
        
        /* Moving average filter for pfcCurrent (averaged over ~1AC cycle and then filtered (avg) over ~8 AC cycles) */
        avgCurrentSum += (avgPFCCurrent - avgCurrentSample[iacArrayIndex]);          
        avgCurrentSample[iacArrayIndex++] = avgPFCCurrent;
        avgPFCCurrent = (avgCurrentSum >> 3);     /* Find average over the ~8 cycles */                         
        
        rmsPFCCurrent = (__builtin_mulss(AVGTORMS, avgPFCCurrent) >> 17) ;    /* RMS Current (Q4.12) = 1.11(Q2.14) * Avg Current (Q1.15) */
        rmsPower = (__builtin_mulss(vacRMS, rmsPFCCurrent) >> 9);            /* Prms = Vrms *Irms = result stays is 4.12 format */
         
        // If operating below 110Vac, to avoid inductor saturation, shutoff supply if power > 675W
        if((rmsPower > INPUTPOWERLOWLINETHRESHOLD) && (vacRMS < INPUTVOLTAGEADC))
        {
            if(++overPowerCnt > 10)
                pfcFaultFlags.LowLineOverPower = ENABLED;
        }
        else {
            overPowerCnt = 0;
        }
        
        pfcStateFlags.NewRMSPower = ENABLED;
        
        #if ((DACOUT == ENABLED) && (DACFUNCT == RMSCURRENT))     
        CMP3DAC = rmsPFCCurrent;
        #endif 

        #if ((DACOUT == ENABLED) && (DACFUNCT == CALCRMSPOWER))     
        CMP3DAC = rmsPower;
        #endif 
        
        if(iacArrayIndex > 7) iacArrayIndex = 0;
    }    
}
/*******************************************************************************
Function: System Voltages
Description:  Calculate moving average of Vac Line voltage , Vac Neutral Voltage for every four samples
****************************************************************************** */
static inline void __attribute__((always_inline, optimize(1))) System_Voltages(void)
{
    int16_t deltaInputVoltage; 
    
    pfcBulkVoltage += ADCBUF1;                                               
    #if ((DACOUT == ENABLED) && (DACFUNCT == BULKVOLTADC))
        CMP3DAC = ADCBUF1;
    #endif
    
    /* Moving average filter for Vin */
    vacLineSum += (ADCBUF2 - vacLineSample[vacArrayIndex]);         
    vacNeutralSum += (ADCBUF3 - vacNeutralSample[vacArrayIndex]);  
    
    vacLine = (vacLineSum >> 2);                            /*  VacLine = VacLineSum/4 */   
    vacNeutral = (vacNeutralSum >> 2);                      /*  VacNeutral = VacNeutralSum/4 */
    vacLineSample[vacArrayIndex] = ADCBUF2;
    vacNeutralSample[vacArrayIndex++]= ADCBUF3;   
    
    #if ((DACOUT == ENABLED) && (DACFUNCT == VINSENSEADC))
        CMP3DAC = (vacLine > vacNeutral) ? ADCBUF2 : ADCBUF3;    
    #endif 
    
    
    if(vacArrayIndex > 3) 
    {
        /* Average Bulk voltage and clear accumulated value   */     
        pfcBulkVoltageFiltered = (pfcBulkVoltage >> 2);                    /* 12bit resolution */ 
        #if ((DACOUT == ENABLED) && (DACFUNCT == BULKVOLTFILT))
            CMP3DAC = pfcBulkVoltageFiltered;
        #endif       
        
        outputBulkVoltage      = pfcBulkVoltageFiltered << SHIFT_Q15;      /* Q15 number format */
        pfcBulkVoltage         = DISABLED;
        vacArrayIndex = 0;                         /* Reset the VacArrayIndex for every four samples */
    }    

    // Manage override of inactive leg
    // Near zero cross both legs should be switching 
    if(pfcStateFlags.RegulationMode == ENABLED)
    {    
        deltaInputVoltage = vacLine - vacNeutral;

        if((deltaInputVoltage > -260) && (deltaInputVoltage < 260))
        {
            if(pfcStateFlags.OverridePWM == ENABLED)
            {
                IOCON1 &= 0xFC3F; // Word writes
                pfcStateFlags.OverridePWM = DISABLED;
            }
            
            overridePWMCnt = 0;
        }
        else
        {         
            if((++overridePWMCnt >= PWMOVERRIDECOUNT) && (pfcStateFlags.OverridePWM == DISABLED))
            {
                pfcStateFlags.OverridePWM = ENABLED;
            
                if(pfcStateFlags.LineActive == ENABLED)
                {
                    IOCON1 = (IOCON1 & 0xFC3F) | 0x0280;  // Word writes
                }    
                else {
                    IOCON1 = (IOCON1 & 0xFC3F) | 0x0140;  // Word writes
                }
            }      
        }        
    }
}

/*******************************************************************************
Function: BulkVoltageManagement
Description:  
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) BulkVoltageManagement(void)
{
    /* Output voltage adjustment when load on the PFC is less than 25% 
       roughly takes 1 second to get to lower threshold  */
    if((rmsPower <= INPUTPOWER25PERCENTCNTS) && (pfcStateFlags.NewRMSPower == ENABLED))
    {   
        #if (LED_DRV1 == BULKVOLTMANAGE)
                DRV_LED1 = ON;
        #endif        
        
        pfcStateFlags.BulkVoltageManagement = ENABLED;

        if(pfcVoltageRef <= PFCVOLTAGEREFADC_LIGHT_LOAD)                     
        {
            pfcVoltageRef = PFCVOLTAGEREFADC_LIGHT_LOAD;                     
        }
        else {
           pfcVoltageRef -= 1;                                   /* Slowly decrease the output voltage from 400V to 380V */
        }
    }
    else if((rmsPower >= INPUTPOWER30PERCENTCNTS) && (pfcStateFlags.BulkVoltageManagement == ENABLED))
    {
        #if (LED_DRV1 == BULKVOLTMANAGE)
                DRV_LED1 = OFF;
        #endif 

        if(pfcVoltageRef >= PFCVOLTAGEREFADC)                      
        {
            pfcStateFlags.BulkVoltageManagement = DISABLED;
            pfcVoltageRef = PFCVOLTAGEREFADC;                                  
        }
        else if (pfcStateFlags.NewRMSPower == ENABLED){
            pfcVoltageRef += 1;                                   /* Slowly increase the output voltage from 380V to 400V */
        }
    }
}

/*******************************************************************************
Function: FETON
Description:  Enable/Disable the parallel FET based on RMS power 
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) FETON(void)
{
    if(rmsPower >= INPUTPOWER30PERCENTCNTS) 
    {
        parellelFEToffCount = DISABLED;
        IOCON2 |= 0x0080;       /* Immediately turn-on parallel FET when input power is above ~30% */                 
    }
    else if ((rmsPower < INPUTPOWER25PERCENTCNTS) && (pfcStateFlags.NewRMSPower == ENABLED))
    {      
        /* Shut down parallel FET after consecutive AC cycles where power is less than 25% */
        if(++parellelFEToffCount >= FETOFFCOUNTLIMIT)
        {
            IOCON2 &= 0xFF7F;   
        }
    }
}

static inline void __attribute__((always_inline, optimize(1))) Dynamic_Gain_Adjustment(void)
{
   int16_t voltageErrorCheck;
       
   voltageErrorCheck = (pfcVoltageErrorControlHistory[0] < 0) ? -pfcVoltageErrorControlHistory[0] : pfcVoltageErrorControlHistory[0];
   
   if((voltageErrorCheck >= TRANSIENTERRORLIMIT) )//&& (pfcStateFlags.TransientMode == DISABLED))
   {
        #if(LED_DRV1 == TRANSIENTMODE)
            DRV_LED1 = ON;
        #endif
        
        pfcVoltageABCoefficients[0] = 28669;                   /* Voltage Loop compensator coefficients assignment */
        pfcVoltageABCoefficients[1] = -28350;
        
        pfcStateFlags.TransientMode = ENABLED;
        transietModeDisablecount = DISABLED;
   }
   else if ((pfcStateFlags.TransientMode == ENABLED) && (voltageErrorCheck <= TRANSIENTERRORLIMIT_HYS)) 
   {      
            pfcVoltageABCoefficients[0] -= 1000;
            pfcVoltageABCoefficients[1] += 1000;
            
            /* Same scale only need to check for one coefficient scale*/
            if(pfcVoltageABCoefficients[0] <= PFCVOLTCOEFFB0)
            {
                pfcVoltageABCoefficients[0] = PFCVOLTCOEFFB0;
                pfcVoltageABCoefficients[1] = PFCVOLTCOEFFB1;
                
                pfcStateFlags.TransientMode = DISABLED;

                #if(LED_DRV1 == TRANSIENTMODE)
                    DRV_LED1 = OFF;
                #endif
            }     
    }
}   