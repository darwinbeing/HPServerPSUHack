/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include <p33Exxxx.h>

#include "init.h"

/*******************************************************************************
Function: 	initClock
Description:	Initialize system clock 
*******************************************************************************/
void initClock(void)
{
    /* PRIMARY OSCILLATOR CLOCK CONFIGURATION*/
    /* Configure Oscillator to operate the device at 70 Mhz  (70 MIPS)*/
    /* Fosc= Fin*M/(N1*N2), 	*/
    /* Fosc= 7.37M*(74+2)/(2*2)=140.03Mhz for 7.37M input clock*/
    /* Fcy = Fosc/2 = ~70MHz*/
    PLLFBD = 74;                               /* M= (PLLFBD+2) = 76 */
    CLKDIVbits.PLLPOST = 0;                    /* N2 = 2 */
    CLKDIVbits.PLLPRE = 0;                     /* N1 = 2 */

    /* Clock switch to incorporate PLL*/
    /* Initiate Clock Switch to FRC oscillator with PLL (NOSC=0b001) */
    __builtin_write_OSCCONH(0x01);
    __builtin_write_OSCCONL(OSCCON | 0x01);
    /* Wait for Clock switch to occur */
    while (OSCCONbits.COSC!= 0b001);
    /* Wait for PLL to lock */
    while (OSCCONbits.LOCK!= 1){}  ;

    /* AUXILLARY CLOCK CONFIGURATION FOR ADC-PWM*/
    /* Setup the ADC and PWM clock for 120MHz; ((FRC * 16) / APSTSCLR ) = (7.37 * 16) / 1 = ~ 120MHz */
     ACLKCONbits.FRCSEL = 1;    			/* FRC provides input for Auxiliary PLL (x16) */
     ACLKCONbits.SELACLK = 1;   			/* Auxiliary Oscillator provides clock source for PWM & ADC */
     ACLKCONbits.APSTSCLR = 7;  			/* Divide Auxiliary clock by 1 */
     ACLKCONbits.ENAPLL = 1;    			/* Enable Auxiliary PLL */

     while(ACLKCONbits.APLLCK != 1);  		/* Wait for Auxiliary PLL to Lock */

     __delay_us(50);                        /* Errata#1 workaround */
}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	initPWM
Description:	Initialize PWM module for PFC Gate Drivers.
*******************************************************************************/
void initPWM(void)
{
    /* PWM1 configured for redundant mode (master time-base) and the inactive phase will
       be disable/enable with the over-ride logic */

    PTCON2bits.PCLKDIV    = (PWMRESOLUTION-1);                    /* 1.06n sec timing resolution */
    PTPER                 = PFCPERIOD;                            /* Boost PFC period value */
    PDC1                  = 0;                                    /* Initialize duty cycle */

    PWMCON1bits.DTC       = 2;                                     /* Dead-time disabled */

    IOCON1 = 0b1100010000000001;    /* PENH/L -1, PMOD-1 (redundant), OSYNC-1 */
    
    /* PWM Fault/Current limit configuration */
    FCLCON1bits.FLTMOD    = 3;                                      /* Disable Fault Mode */
    FCLCON1bits.CLMOD     = 1;                                      /* Current Limit Enabled */
    FCLCON1bits.CLSRC     = 0b01101;                                /* Current Limit Source is CMP1 */

    LEBCON1 = 0xA400;                             
    LEBDLY1 = 0x0200;                                               /* Delay ~500ns*/

    /* Trigger for ADC Module */
    TRGCON1bits.TRGDIV   = 0;                                       /* Trigger ADC every PWM Period */
    TRGCON1bits.TRGSTRT  = 0;                                       /* Wait 0 PWM cycles before first PWM trigger */
    TRIG1                = 8;                                       /* PWM1 used to trigger ADCAN0 Channel */
    
    /* Special Event for ADC trigger of AN1/AN2/AN3 (sync with AN0 but every other PWM cycle) */
    PTCONbits.SEVTPS     = 1;                                       /* Every other PWM Cycle 50kHz (AN3 Interrupt) */                          
    SEVTCMP              = 8;                                    
    
    /* PWM2 Override control for parallel FET and Relay drive */
    IOCON2 = 0b1100011110000001;      /* PENH/L -1, OVERENH/L - 1, PMOD-1, OSYNC-1, Parallel FET-ON */
    FCLCON2bits.FLTMOD   = 3;

    #if(CURRTRIGPOINT == ENABLED)
        //PDC4 remapped to I/O pin to show ADC trigger instant
        IOCON4 = 0b1000010000000001;
        FCLCON4bits.FLTMOD   = 3;

        _RP43R = 0b110011;
    #endif
    
    PTCONbits.PTEN       = 1;                                /* Enable PWM Module */
}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	initADC
Description:	Initialize ADC module and ADC interrupts 
       AN0 PFC Current Sense                         AN1 Bulk Voltage Sense 
       AN2/3 AC Voltage Sense (Line/Neutral)         AN6 Auxiliary Voltage Sense 
       AN7 Temperature Sense 
*******************************************************************************/
void initADC(void)
{
    /* Setup ADC Clock Input Max speed of 70MHz */
    ADCON3Hbits.CLKSEL  = 1;                          /* 0-Fsys, 1-Fosc, 2-FRC, 3-APLL */
    ADCON3Hbits.CLKDIV  = 0;                          /* Global Clock divider (1:1) */
    // Core clock divider defaults to (1:2) 
    ADCON1Hbits.FORM    = 0;                          /* Integer format */
    ADCON3Lbits.REFSEL  = 0;                          /* AVdd as voltage reference */
    // Resolution defaults to 12-bits
    ADCON1Hbits.SHRRES  = 3;                          /* ADC Cores in 12-bit resolution mode */
    ADCON2Hbits.SHRSAMC = 2;                          /* Shared ADC Core sample time 4Tad */

    /* Configure ANx for unsigned format and single ended (0,0) */
    ADMOD0L             = 0x0000;
    
    ADCON5Hbits.WARMTIME  = 11;                       /*ADC power up delay  */    
    ADCON1L = 0x0000;
    ADCON1Lbits.ADON      = 1;                        /* Turn on ADC module  */

    /* Turn on analog power for dedicated core 0 */
    ADCON5Lbits.C0PWR     = 1;
    while(ADCON5Lbits.C0RDY == 0);
    ADCON3Hbits.C0EN      = 1;

    /* Turn on analog power for dedicated core 1 */
    ADCON5Lbits.C1PWR     = 1;
    while(ADCON5Lbits.C1RDY == 0);
    ADCON3Hbits.C1EN      = 1;
    
    /* Turn on analog power for dedicated core 0 */
    ADCON5Lbits.C2PWR     = 1;
    while(ADCON5Lbits.C2RDY == 0);
    ADCON3Hbits.C2EN      = 1;

    /* Turn on analog power for dedicated core 1 */
    ADCON5Lbits.C3PWR     = 1;
    while(ADCON5Lbits.C3RDY == 0);
    ADCON3Hbits.C3EN      = 1;

    /* Turn on analog power for shared core */
    ADCON5Lbits.SHRPWR    = 1;
    while(ADCON5Lbits.SHRRDY == 0);
    ADCON3Hbits.SHREN     = 1;
    
    calibrateADC();
    
    /* Setup AN0 Trigger Source/Interrupt for PFC Current Sense */
    ADTRIG0Lbits.TRGSRC0 = 5;                                          /* AN0 triggered by PWM1 */
    ADIELbits.IE0        = 1;
    IFS6bits.ADCAN0IF    = 0;                                          /* Clear ADC interrupt flag */
    IPC27bits.ADCAN0IP   = 7;                                          /* Set ADC interrupt priority (IPL 7 uses Alt W-REG #1) */
    IEC6bits.ADCAN0IE    = 1;                                          /* Enable the AN0 interrupt (Current Loop Compensator) */
    
    /* Setup AN1/AN2/AN3 Trigger Source and generate Interrupt for AN3 only */
    ADTRIG0Lbits.TRGSRC1 = 4;                                          /* Special Event Interrupt triggers Bulk Voltage( AN1) and AC Mains Sampling (AN2 and AN3) */
    ADTRIG0Hbits.TRGSRC2 = 4;                                          /* Ensure trigger occurs after conversion of AN0 for AN1/AN2/AN3 */
    ADTRIG0Hbits.TRGSRC3 = 4;
    
    ADIELbits.IE3        = 1;
    IFS7bits.ADCAN3IF    = 0;                                          /* Clear ADC interrupt flag */
    IPC28bits.ADCAN3IP   = 6;                                          /* Set ADC interrupt priority */
    IEC7bits.ADCAN3IE    = 1;                                          /* Enable AN3 interrupt (Voltage Loop Compensator) */
   
    /* Setup AN6 Trigger Source */
    ADTRIG1Hbits.TRGSRC6 = 1;                                          /* SW Trigger, Shared S&H conversions when no other core is converting */
                                            
    initDigCMP();                                                      /* Configure Digital comparator for temperature and driver supply faults */
}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	calibrateADC
Description: calibration of ADC cores (AN0,AN1,AN2,AN3 and Shared core)
*******************************************************************************/
void calibrateADC(void)
{ 
    /* Enable calibration for the dedicated core 0 */
    ADCAL0Lbits.CAL0EN    = 1;
    ADCAL0Lbits.CAL0DIFF  = 0;                                         /* Single-ended input calibration */
    ADCAL0Lbits.CAL0RUN   = 1;                                         /* Start Calibration */
    while(ADCAL0Lbits.CAL0RDY == 0);
    ADCAL0Lbits.CAL0EN    = 0;                                         /* Calibration complete */

    /* Enable calibration for the dedicated core 1 */
    ADCAL0Lbits.CAL1EN    = 1;
    ADCAL0Lbits.CAL1DIFF  = 0;                                         /* Single-ended input calibration */
    ADCAL0Lbits.CAL1RUN   = 1;                                         /* Start Calibration */
    while(ADCAL0Lbits.CAL1RDY == 0);
    ADCAL0Lbits.CAL1EN    = 0;                                         /* Calibration complete */

    /* Enable calibration for the dedicated core 2 */
    ADCAL0Hbits.CAL2EN    = 1;
    ADCAL0Hbits.CAL2DIFF  = 0;                                         /* Single-ended input calibration */
    ADCAL0Hbits.CAL2RUN   = 1;                                         /* Start Calibration */
    while(ADCAL0Hbits.CAL2RDY == 0);
    ADCAL0Hbits.CAL2EN    = 0;                                         /* Calibration complete */

    /* Enable calibration for the dedicated core 3 */
    ADCAL0Hbits.CAL3EN    = 1;
    ADCAL0Hbits.CAL3DIFF  = 0;                                         /* Single-ended input calibration */
    ADCAL0Hbits.CAL3RUN   = 1;                                         /* Start Calibration */
    while(ADCAL0Hbits.CAL3RDY == 0);
    ADCAL0Hbits.CAL3EN    = 0;                                         /* Calibration complete */  

    /* Enable calibration for the shared core */
    ADCAL1Hbits.CSHREN    = 1;
    ADCAL1Hbits.CSHRDIFF  = 0;                                         /* Single-ended input calibration */
    ADCAL1Hbits.CSHRRUN   = 1;                                         /* Start Calibration */
    while(ADCAL1Hbits.CSHRRDY == 0);
    ADCAL1Hbits.CSHREN    = 0;                                         /* Calibration complete */
}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	initDigCMP
Description:	Initialize digital comparators
*******************************************************************************/
void initDigCMP(void)
{
     /* Digital Comparator 1 for auxiliary supply monitoring  with hysteresis*/
    ADCMP1HI  = DRVOVERVOLTAGEADC;                        /* Upper voltage setting */
    ADCMP1LO  = DRVUNDERVOLTAGEADC;                       /* Lower voltage setting */
    
    ADCMP1CON = 0x0089;         /* Enable digital comparator interrupt, Interrupt on HIHI and LOLO events */

    ADCMP1ENLbits.CMPEN6    = 1;                                        /* ADCBUF6 processed by digital comparator */
    IPC44bits.ADCMP1IP      = 5;                                        /* ADCMP1 interrupt priority is 5 */
    IFS11bits.ADCMP1IF      = 0;                                        /* clear interrupt flag */
    IEC11bits.ADCMP1IE      = 1;                                        /* Enable the ADCMP1 interrupt */
    
    ADCMP1CONbits.CMPEN = 1;
}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	initIOPorts
Description:	Initialize all IO pins
*******************************************************************************/
void initIOPorts(void)
{
    TRISAbits.TRISA0        = 1;      /* Configure RB1 as input pfcCurrent (Analog Comparator)*/
    TRISBbits.TRISB4        = 0;      /* Configure RB4 as output LEDDRV1 */
    TRISBbits.TRISB8        = 0;      /* Configure RB8 as output LEDDRV2  */
    TRISBbits.TRISB13       = 0;      /* Configure RB13 as output to turn of parallel MOSFET */
    TRISBbits.TRISB14       = 0;      /* Configure RB14 as output Relay Drive control */

    LATBbits.LATB4          = 0;      /* turn-off the LEDDRV1 during the start up  */
    LATBbits.LATB8          = 0;      /* turn-off the LEDDRV2 during the start up  */                        
    LATBbits.LATB13         = 0;      /* turn-off the Parallel MOSFET during the start up  */
    
    ANSELBbits.ANSB4        = 0;
    ANSELBbits.ANSB5        = 0;      /* Set RB5 in Digital Mode (Transmission signal to DC-DC) */
    
    #if(DACOUT == DISABLED)
        ANSELBbits.ANSB3 = 0;             /* Use as General Purpose I/O */
        TRISBbits.TRISB3 = 0;
    #endif

    #if(LED_DRV1 == POWER_ON)
       DRV_LED1 = ENABLED;
    #endif 
    
}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	initCMP
Description:	Initialize comparator modules
*******************************************************************************/
void initCMP(void)
{
    /* Comparator 1A (PFC Current) */
    CMP1CONbits.INSEL       = 0;            /* CMP1A as input */
    CMP1CONbits.HYSSEL      = 3;            /* Add hysteresis */
    CMP1CONbits.RANGE       = 1;
    CMP1DAC                 = STARTUPCURRENT;                
    IFS1bits.AC1IF          = 0;
    IPC4bits.AC1IP          = 5;

    CMP1CONbits.CMPON       = 1;                                              
    
    #if(DACOUT == ENABLED)
        CMP3CONbits.RANGE      = 1;
        CMP3CONbits.DACOE      = 1;        /* Enable DACOUT for debug purpose */
        CMP3CONbits.CMPON      = 1;        /* Enable for debug purpose */
    #endif    
}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	initTMR
Description:	Initialize Timers (Timer3 ISR used for Soft start and protection)
 *                                 Timer5 ISR for IC-IC communication
*******************************************************************************/
void initTMR(void)
{    
    /* Configure TMR3 for System Protection */
    PR3             = TMR3PERIOD;                              
    T3CONbits.TCKPS = TMR3SCALER;                 
    IEC0bits.T3IE   = 1;                                        
    IPC2bits.T3IP   = 5;                                       
    T3CONbits.TON   = 1;                                       
 
    // Timer 5 used for scheduling RX/TX between ICs
    T5CONbits.TCKPS = 1;
    PR5 = 17500;   //~2ms
    _T5IP = 4;      
    _T5IE = 1;

}
/*******************************************************************************
End of Function
*******************************************************************************/

/*******************************************************************************
Function: 	disableModules
Description:	Disable all unused modules PMD bits
*******************************************************************************/
void disableModules(void)
{
    /* Disable Constant current source mode */
    /* Disable PGA2 module */
    PMD8 = 0x0402;
    
    /* Disable Analog comparators 2/4  */
   /* Disable PGA1 module */
    PMD7 = 0x0A02;
    
    /* Disable PWM3/PWM4/PWM5 module */
    #if(CURRTRIGPOINT == DISABLED)
        PMD6 = 0x1C00;
    #else
        PMD6 = 0x1400;
    #endif
    
    /* Disable REFO */
    PMD4 = 0x0008;
    
    /* Disable I2C2 module */
    PMD3bits.I2C2MD     = 1;          
    
    /* Disable Input Capture 1/2/3/4 module */
    /* Disable Output Compare 1/2/3/4 module */
    PMD2 = 0x0F0F;
    
    /* Disable I2C1 module */
    /* Disable SPI1/SPI2 module */
    /* Disable Timer 1/4 module */
    /* UART2 module left enabled in cases of debugging */
    PMD1 = 0x4898;
}
/*******************************************************************************
End of Function
*******************************************************************************/
