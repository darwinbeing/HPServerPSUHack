/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include "main.h"

/* FSEC */
#pragma config BWRP = OFF               /* Boot Segment Write-Protect bit (Boot Segment may be written)*/
#pragma config BSS = DISABLED           /* Boot Segment Code-Protect Level bits (No Protection (other than BWRP))*/
#pragma config BSEN = OFF               /* Boot Segment Control bit (No Boot Segment)*/
#pragma config GWRP = OFF               /* General Segment Write-Protect bit (General Segment may be written)*/
#pragma config GSS = DISABLED           /* General Segment Code-Protect Level bits (No Protection (other than GWRP))*/
#pragma config CWRP = OFF               /* Configuration Segment Write-Protect bit (Configuration Segment may be written)*/
#pragma config CSS = DISABLED           /* Configuration Segment Code-Protect Level bits (No Protection (other than CWRP))*/
#pragma config AIVTDIS = OFF            /* Alternate Interrupt Vector Table bit (Disabled AIVT) */

/* FBSLIM */
#pragma config BSLIM = 0x1FFF           /* Boot Segment Flash Page Address Limit bits (Boot Segment Flash page address  limit) */

/* FSIGN */

/* FOSCSEL */
#pragma config FNOSC = FRC              /* Oscillator Source Selection (Internal Fast RC (FRC)) */
#pragma config IESO = ON                /* Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source) */

/* FOSC */
#pragma config POSCMD = NONE            /* Primary Oscillator Mode Select bits (Primary Oscillator disabled) */
#pragma config OSCIOFNC = ON            /* OSC2 Pin Function bit (OSC2 is general purpose digital I/O pin) */
#pragma config IOL1WAY = OFF            /* Peripheral pin select configuration bit (Allow multiple reconfigurations) */
#pragma config FCKSM = CSECMD           /* Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled) */
#pragma config PLLKEN = ON              /* PLL Lock Enable Bit (Clock switch to PLL source will wait until the PLL lock signal is valid) */

/* FWDT */
#pragma config WDTPOST = PS16           /* Watchdog Timer Postscaler bits (1:16)*/
#pragma config WDTPRE = PR32            /* Watchdog Timer Prescaler bit (1:32)*/
#pragma config WDTEN = OFF              /* Watchdog Timer Enable bits (WDT and SWDTEN disabled)*/
#pragma config WINDIS = OFF             /* Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode) */
#pragma config WDTWIN = WIN25           /* Watchdog Timer Window Select bits (WDT Window is 25% of WDT period) */


/* FICD */
#pragma config ICS = PGD1               /* ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1) */
#pragma config JTAGEN = OFF             /* JTAG Enable bit (JTAG is disabled) */
#pragma config BTSWP = ON              /* BOOTSWP Instruction Enable/Disable bit (BOOTSWP instruction is disabled) */

/* FDEVOPT */
#pragma config PWMLOCK = OFF            /* PWMx Lock Enable bit (PWM registers may be written without key sequence) */
#pragma config ALTI2C1 = OFF            /* Alternate I2C1 Pin bit (I2C1 mapped to SDA1/SCL1 pins)*/
#pragma config ALTI2C2 = OFF            /* Alternate I2C2 Pin bit (I2C2 mapped to SDA2/SCL2 pins) */
#pragma config DBCC = OFF               /* DACx Output Cross Connection bit (No Cross Connection between DAC outputs) */

/* FALTREG */
#pragma config CTXT1 = IPL7             /* Specifies Interrupt Priority Level (IPL) Associated to Alternate Working Register 1 bits (Alternate Register set assigned to IPL level 7) */
#pragma config CTXT2 = OFF              /* Specifies Interrupt Priority Level (IPL) Associated to Alternate Working Register 2 bits (Not Assigned) */


#if defined(__DUAL_PARTITION)
EZBL_SET_CONF(_FBOOT, BTMODE_DUAL)  // Default is BTMODE_SINGLE, BTMODE_DUAL is for ping-ponging, BTMODE_DUALPROT is for statically write-protecting Partition 1, BTMODE_DUALPRIV is reserved/do not use
#endif

volatile uint16_t timeForPartitionSwap = 0;
volatile uint16_t __attribute__((near)) criticalISRDone = 0;
                                  

void __attribute__((priority(100), optimize(1))) CriticalInit(void)
{
    if(!_SFTSWP) {      
        return;
    }
    
    #if (LED_DRV1 == SWITCHOVER)
        DRV_LED1 = DISABLED;
    #endif  
    
    //Clear new flags at partition swap    
    pfcStateFlags.PeakDetect = 0;
    pfcStateFlags.FrequencyADJ = 0;
        
    // Re-enable critical ISRs (current loop)            
    _ADCAN0IE = 1;
    _ADCAN3IE = 1;
    _AC1IE = 1;
}

void __attribute__((priority(200), optimize(1))) SecondaryInit(void)
{
    if(!_SFTSWP) {      
        return;
    }

    // Need to initialize DAC if new FW uses it
    #if(DACOUT == ENABLED)
        ANSELBbits.ANSB3 = 1;
        CMP3CONbits.RANGE = 1;
        CMP3CONbits.DACOE = 1;        /* Enable DACOUT for debug purpose */
        CMP3CONbits.CMPON = 1;        /* Enable for debug purpose */
    #endif 
    
    // Re-enable next critical ISRs
    _T3IE = 1;
    _ADCMP1IE = 1;   
}

    
int main()
{  
    if((RCONbits.TRAPR == 1) || (RCONbits.IOPUWR == 1))
    {
        while(1);       // Do not proceed , device reset not intended
    }
     
    Nop();
    Nop();
    Nop();

    // Check if we are entering main via an ordinary device reset or via a hot 
    // Bootloader partition swap
    if(!_SFTSWP)    // Ordinary reset initialization - do not execute for live update
    {  
        
        #if (TESTMODE == ENABLED)
            TRISBbits.TRISB4 = 0;
            __asm__("bclr _ANSELB, #4");
            DRV_LED1 = ON;
            initClock();
            initPWM();              /* 50% DC nothing else executing */
            PDC1 = PTPER >> 1;
            while(1);
        #endif  
        
        
        pfcFaultFlags.SystemFaults = DISABLED;
        pfcFaultFlags.MainsVoltage = ENABLED ;
        pfcStateFlags.SystemState = DISABLED;
        pfcStateFlags.StartUp = ENABLED;

        // Initialize the bootloader as the very first thing to minimize bricking 
        // possibilities. This will block for 1 second to give a small bootloading 
        // "guaranteed" window.
        EZBL_BootloaderInit();
        
        initClock();            /* Configure Device Oscillators */        
        disableModules();       /* Disable all unused modules */
        initIOPorts();          /* Initialize all I/O Ports */
        initCMP();              /* Configure comparator module */
        initPFCComp();          /* Setup V/I Loop Compensators */
        initTMR();              /* Setup Timers */
        initADC();              /* Initialize ADC Module */
        
        IEC1bits.AC1IE = 1;     /* Enable ISR after enabling CMP but before turning on PWM */
        
        initPWM();              /* Initialize PWM Module  */ 
        uartCommFunct();        /* Communication w/ DCDC */
    }   
    else {
        NVMCONbits.SFTSWP = 0;   
      
        UART1_RxFifo.onReadCallback = UART1_RX_FIFO_OnRead;
        UART1_TxFifo.onWriteCallback = UART1_TX_FIFO_OnWrite;
        UART1_RxFifo.flushFunction   = UART1_RX_FIFO_Flush;
        UART1_TxFifo.flushFunction   = UART1_TX_FIFO_Flush;
    
        EZBL_bootloaderTask.callbackFunction = EZBL_BootloaderTaskFunc;
        
        _T2IE = 1;      // Timer 2 NOW tick timing code (now.c)
        _U1TXIE = 1;    // UART 1 TX PFC Communication
        _U1RXIE = 1;    // UART 1 RX PFC Communication
        _T5IE = 1;      // Handling IC-IC communication
        
        DRV_LED1 = ON;      //Just for testing visual of actually switching partitions - Off in V1/V3
    }
       
    while(1)
    {       
        if(timeForPartitionSwap)
        {
            timeForPartitionSwap = 0;
            
            // Disable all interrupts except for the critical interrupts
            // which we want to synchronize the bootswap with
            _T2IE = 0;      // Timer 2 NOW tick timing code (now.c)
            _U1TXIE = 0;    // UART 1 TX PFC Communication
            _U1RXIE = 0;    // UART 1 RX PFC Communication
            _T5IE = 0;      // For handling IC-IC communication
            _T3IE = 0;      // Protection/Fault management
            _ADCMP1IE = 0;  // Digital CMP for aux faults
            _AC1IE = 0;     // Analog CMP ISR
            
            // AN0/AN3 ISR disabled after synchronization for partition swap
            
            criticalISRDone = 0;            // Clear variable, PWM3 ISR set bit 0, ADCAN0 sets bit 1 
            while(criticalISRDone != 3u);   // Wait for variable to change, indicating the ISRs have just finished
            
            #if (LED_DRV1 == SWITCHOVER)
                DRV_LED1 = ENABLED;
            #endif 
           
            EZBL_PartitionSwap();           // Perform the partition swap and branch to 0x000000 on the (presently) Inactive Partition
        }    
        
    }
      
    return 0;      
}
