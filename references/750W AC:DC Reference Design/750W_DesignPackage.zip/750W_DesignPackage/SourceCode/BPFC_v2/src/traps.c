/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__dsPIC33E__)
	#include <p33Exxxx.h>
#endif

#include <stdint.h>        /* Includes uint16_t definition */
#include <stdbool.h>       /* Includes true/false definition */

#include "defines.h"
#include "libpic30.h"
#include "..\ezbl_integration/ezbl.h"

#define DEBUG_TRAP  DISABLED

/******************************************************************************/
/* Trap Function Prototypes                                                   */
/******************************************************************************/
void __attribute__((interrupt,no_auto_psv)) _OscillatorFail(void);
void __attribute__((interrupt,no_auto_psv)) _AddressError(void);
void __attribute__((interrupt,no_auto_psv)) _StackError(void);
void __attribute__((interrupt,no_auto_psv)) _MathError(void);

/* Default interrupt handler */
void __attribute__((interrupt,no_auto_psv)) _DefaultInterrupt(void);

/* These are additional traps in the 33E family.  Refer to the PIC33E
migration guide.  There are no Alternate Vectors in the 33E family. */
void __attribute__((interrupt,no_auto_psv)) _HardTrapError(void);
void __attribute__((interrupt,no_auto_psv)) _SoftTrapError(void);


/******************************************************************************/
/* Trap Handling                                                              */
/*                                                                            */
/* These trap routines simply ensure that the device continuously loops       */
/* within each routine.  Users who actually experience one of these traps     */
/* can add code to handle the error.  Some basic examples for trap code,      */
/* including assembly routines that process trap sources, are available at    */
/* www.microchip.com/codeexamples                                             */
/******************************************************************************/

#if (DEBUG_TRAP == DISABLED)
/* Primary (non-alternate) address error trap function declarations */
void __attribute__((interrupt,no_auto_psv)) _OscillatorFail(void)
{
        INTCON1bits.OSCFAIL = 0;        /* Clear the trap flag */
        PTCONbits.PTEN = 0;
        DRV_LED2 = ON;
        while(1);
}

void __attribute__((interrupt,no_auto_psv)) _AddressError(void)
{
        INTCON1bits.ADDRERR = 0;        /* Clear the trap flag */
        PTCONbits.PTEN = 0;
        DRV_LED2 = ON;
        while(1);
}

void __attribute__((interrupt,no_auto_psv)) _StackError(void)
{
        INTCON1bits.STKERR = 0;         /* Clear the trap flag */
        PTCONbits.PTEN = 0;
        DRV_LED2 = ON;
        while(1); 
}

void __attribute__((interrupt,no_auto_psv)) _MathError(void)
{
        INTCON1bits.MATHERR = 0;        /* Clear the trap flag */
        PTCONbits.PTEN = 0;
        DRV_LED2 = ON;
        while(1);
}


/******************************************************************************/
/* Default Interrupt Handler                                                  */
/*                                                                            */
/* This executes when an interrupt occurs for an interrupt source with an     */
/* improperly defined or undefined interrupt handling routine.                */
/******************************************************************************/
void __attribute__((interrupt, no_auto_psv)) _DefaultInterrupt(void)
{
    PTCONbits.PTEN = 0;
    DRV_LED2 = ON;
    while(1);
}

/* These traps are new to the dsPIC33E family.  Refer to the device Interrupt
chapter of the FRM to understand trap priority. */
void __attribute__((interrupt,no_auto_psv)) _HardTrapError(void)
{    
    PTCONbits.PTEN = 0;
    DRV_LED2 = ON;
    while(1);
}

void __attribute__((interrupt,no_auto_psv)) _SoftTrapError(void)
{
    if (INTCON3bits.APLL == 1)
    {
        INTCON3bits.APLL = 0;
    }
    else
    {    
        PTCONbits.PTEN = 0;
        DRV_LED2 = ON;
        while(1);
    }
}

#else

void DumpRAM(unsigned int startAddr, unsigned int endAddr)
{
    unsigned int i;

    if(endAddr == startAddr)
        return;

    if(startAddr & 0x000Fu)
    {
        EZBL_printf("\n  %04X  ", startAddr & 0xFFF0u);
        i = startAddr & 0x000Eu;
        while(i)
        {
            EZBL_printf("     ");
            i -= 2u;
        }
        if(startAddr & 0x0001u)
        {
            EZBL_printf("%02X   ", (unsigned int)*((unsigned char*)(startAddr)));
            startAddr++;
        }
    }

    i = endAddr & 0xFFFEu;
    while(startAddr < i)
    {
        if((startAddr & 0xFu) == 0u)    // Start of new line?
        {
            EZBL_printf("\n  %04X  ", startAddr & 0xFFF0u);
        }
        EZBL_printf("%04X ", *((unsigned int*)(startAddr)));
        startAddr += 2u;
    }

    if(endAddr & 0x1)
    {
        EZBL_printf("  %02X", (unsigned int)(*((unsigned char*)(startAddr))));
    }
    EZBL_printf("\n");
}

struct
{
    unsigned int w[16];
    unsigned int rcount;
    unsigned int dsrpag;
    unsigned int dswpag;
    unsigned int sr;
} contextRegs;


void __attribute__((interrupt(preprologue("\n"
    "\n     mov w0, _contextRegs+0"
    "\n     mov w1, _contextRegs+2"
    "\n     mov _RCOUNT, w1"
    "\n     mov w1, _contextRegs+32"
    "\n     mov #30, w1"
    "\n     mov #(_contextRegs+30), w0"
    "\n     repeat #13"
    "\n     mov [w1--], [w0--]"
    "\n     mov _DSRPAG, w1"
    "\n     mov w1, _contextRegs+34"
    "\n     mov _DSWPAG, w1"
    "\n     mov w1, _contextRegs+36"
    "\n     mov _SR, w1"
    "\n     mov w1, _contextRegs+38"
    "\n     mov _contextRegs+32, w1"
    "\n     mov w1, _RCOUNT"
    "\n     mov _contextRegs+2, w1"
    "\n     mov _contextRegs+0, w0"
)), auto_psv)) _DefaultInterrupt(void)
{
    unsigned long retInstr[3];
    unsigned long frameRetAddr;
    unsigned long retAddr;
    unsigned int retIPL;
    unsigned int retSR;
    unsigned int retSFA;
    unsigned int i;
    

#if(LED_DRV1 == TRAP)
    DRV_LED1 = ENABLED;
#endif

    PTCONbits.PTEN = 0;     //Disable PWM module
    
    
    contextRegs.w[15] -= 0x4u;    // Subtract 0x4 from the stack pointer to remove ISR return address/SR data
    EZBL_RAMCopy(&retAddr, (unsigned long*)contextRegs.w[15], 4);
    retSR = (unsigned int)(((unsigned char*)&retAddr)[3]);
    retIPL = (unsigned int)(((((unsigned char*)&retAddr)[2]) & 0x80)>>4) | (retSR>>5);
    retSFA = ((unsigned int)retAddr) & 0x1u;
    retAddr = retAddr & 0x007FFFFEu;
    
    EZBL_printf("\n\n_DefaultInterrupt(): "
                  "\n  RCON    0x%04X"
                  "\n  INTCON1 0x%04X"
                  "\n  RCOUNT  0x%04X"
                  "\n  DSRPAG  0x%04X"
                  "\n  DSWPAG  0x%04X"
                  "\n  SR      0x%04X"
                  "\n  crcn    0x%04X",
                  RCON, INTCON1, contextRegs.rcount, contextRegs.dsrpag, contextRegs.dswpag, contextRegs.sr, CORCON);

    RCON = 0;
    
    for(i = 0; i < 16; i++)
    {
        EZBL_printf("\n  w%- 7u0x%04X", i, contextRegs.w[i]);
    }
    
    if(contextRegs.w[14] && retSFA)
    {
        EZBL_RAMCopy(&frameRetAddr, (unsigned long*)(contextRegs.w[14] - 6u), 4);
        frameRetAddr &= 0xFFFFFFFEu;
        EZBL_printf("\n  Caller returns to: 0x%06lX (SFA = %X)", frameRetAddr & 0xFFFFFFFEu, ((unsigned int)frameRetAddr) & 0x0001u);
    }
    EZBL_printf("\n  Interrupt return address: 0x%06lX (SFA = %X, IPL = %X, SR<7:0> = 0x%02X)"
                "\n", retAddr, retSFA, retIPL, retSR);

    DumpRAM(contextRegs.w[15] - 0x100, contextRegs.w[15]);

    EZBL_ReadUnpacked(retInstr, retAddr-0x4, sizeof(retInstr));
    EZBL_printf("\n  Preceeding opcode:  %06lX"
                "\n  Interrupted opcode: %06lX"
                "\n  Resume opcode:      %06lX",
                retInstr[0], retInstr[1], retInstr[2]);

    
    //UART2_TX_FIFO_WaitUntilFlushed();
    
    while(UART2_TxFifo.dataCount > 0u)
    {   // Get a byte from the TX buffer
        U2TXREG = *UART2_TxFifo.tailPtr++;
        if(UART2_TxFifo.tailPtr >= UART2_TxFifo.fifoRAM + UART2_TxFifo.fifoSize)
            UART2_TxFifo.tailPtr = UART2_TxFifo.fifoRAM;
        EZBL_ATOMIC_SUB(UART2_TxFifo.dataCount, 1);
        __delay_us(2);           
    }
    
    while(1);
}
#endif
