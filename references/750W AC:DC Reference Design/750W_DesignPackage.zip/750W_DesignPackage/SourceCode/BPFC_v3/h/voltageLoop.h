/*******************************************************************************
Microchip's products.  Microchip and its licensors retain all ownership and
intellectual property rights in the accompanying software and in all
derivatives here to.

This software and any accompanying information is for suggestion only. It
does not modify Microchip's standard warranty for its products. You agree
that you are solely responsible for testing the software and determining its
suitability. Microchip has no obligation to modify, test, certify, or
support the software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR
PURPOSE APPLY TO THIS SOFTWARE, ITS INTERACTION WITH MICROCHIP?S PRODUCTS,
COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

IN NO EVENT, WILL MICROCHIP BE LIABLE, WHETHER IN CONTRACT, WARRANTY, TORT
(INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), STRICT LIABILITY,
INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, PUNITIVE,
EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF
ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWSOEVER CAUSED, EVEN IF
MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.
TO THE FULLEST EXTENT ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF
FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
THESE TERMS.
*******************************************************************************/

#include "init_Compensators.h"
#include "pfc_Variables.h"

#define MAXLIMITQ15                                 32767       
#define MAXLIMITQ14                                 16383
#define MAXLIMITQ13                                 8191

#define VPK2VRMS                                    23170       /* 2^15 * .7071 (1/sqrt(2)) in Q15 format) */
#define AVGTORMS                                    18198       /* 1.11 in 2.14 format to calculate RMS value from AVG value */

/* Current Offset parameters*/
#define CURRENT_OFFSET_10PC                         800         /* Current Offset at No-Load */       
#define CURRENT_OFFSET_100PC                        650         /* Current Offset at 100% of Load at 115V line */       
#define CURRENT_OFFSET_100PC_1                      250         /* Current Offset at 100% of Load at 230V line */   

/*Current Reference calculation related parameters */
#define VOLTAGECOMP_BELOW_10PC                      200       /* Voltage Compensator value corresponding to no-load */ 
#define VOLTAGECOMP_ABOVE_10PC                      3500      /* Voltage Compensator value corresponding to below 20% loading */
#define VOLTAGECOMP_ABOVE_50PC                      10000     /* Voltage Compensator value corresponding to 50% loading */    
#define VACUPPERTHRESHOLD                           25000     /* Mains Voltage threshold to change the Duty Feedforward compensator */
#define VOLTCOMPLIMIT                               5500      /* Voltage compensator threshold to change the Current Loop compensator*/

/* VRMS,OVERCURRENT parameters */
#define VRMS_COUNT_LIMIT                            5         /* upcount and downcount limit while calculating the VRMS value */


/* (Vrms*.00704*1241^2*Iacrms*.165) >> 9 to maintain Q12 */
#define INPUTPOWER25PERCENTCNTS                     698       /* When less than ~25% enter routine */  
#define INPUTPOWER30PERCENTCNTS                     855       /* Exit routine when ~>30% */                           

#define INPUTPOWERLOWLINETHRESHOLD                  2200      // Prevent inductor saturation

#define TRANSIENTERRORLIMIT                         830 //600 original 800 working at 110 
#define TRANSIENTERRORLIMIT_HYS                     700
#define PWMOVERRIDECOUNT                            10        /* Counter to wait to override PWM inactive leg */
#define FETOFFCOUNTLIMIT                            10        /* 10 AC cycles to turn off parallel FET */
#define TRANSIENTMODEDISABLECOUNT                   10

#define INPUTVOLTAGE                                105      /* input Voltage threshold in volts for overcurrent protection */
#define INPUTVOLTAGEADC                             (int)(INPUTVOLTAGE*VACFBGAIN*ADCRESOLUTION)

#define INPUTVOLTAGEHIGHLINE                        170
#define INPUTVOLTAGEHIGHLINEADC                     (int)(INPUTVOLTAGEHIGHLINE*VACFBGAIN*ADCRESOLUTION)
#define INPUTVOLTAGEHIGHLINEHYSADC                  (int)((INPUTVOLTAGEHIGHLINE+10)*VACFBGAIN*ADCRESOLUTION)

/* Mains frequency check parameters */  
#define FREQUENCYCOUNT_FILTER                       200


typedef union{

    struct {
        uint16_t MainsVoltage           : 1;
        uint16_t MainsFreq              : 1;
        uint16_t DrvSupply              : 1;
        uint16_t MainsUnderVoltage      : 1;
        uint16_t MainsOverVoltage       : 1;
        uint16_t OutputUnderVoltage     : 1;
        uint16_t OutputOverVoltage      : 1;
        uint16_t OverCurrent            : 1;
        uint16_t DCDCFaultMode          : 1;
        uint16_t Communication          : 1;
        uint16_t ShutDownDCDC           : 1;
        uint16_t LowLineOverPower       : 1;
        uint16_t : 4;
    };
    
    uint16_t SystemFaults;

} PFC_FAULTS;

typedef union {

   struct {
        uint16_t SoftStartActive        : 1;
        uint16_t StartUp                : 1;
        uint16_t RegulationMode         : 1;
        uint16_t NewInputRMS            : 1;
        uint16_t SyncZeroCross          : 1;
        uint16_t LineActive             : 1;
        uint16_t DCDCRegulationMode     : 1;
        uint16_t BulkVoltageManagement  : 1;
        uint16_t NewRMSPower            : 1;
        uint16_t TransientMode          : 1;
        uint16_t ZeroCrossDetect        : 1;
        uint16_t OverridePWM            : 1;
        uint16_t PeakDetect             : 1;            /* Flag is set once AC peak is found, cleared at ZC, used for adaptive freq @ ZC*/
        uint16_t FrequencyADJ           : 1;
        uint16_t DisableDCMCorr         : 1;
        uint16_t HighLineActive         : 1;
    };
    uint16_t SystemState;
    

} PFC_FLAGS;

extern volatile PFC_FAULTS pfcFaultFlags;                                   /* Flags for Fault conditions  */
extern volatile PFC_FLAGS pfcStateFlags;                                   /* Flags for System conditions */

extern void SMPS_Controller2P2ZUpdate_HW_Accel(void);               /* Voltage Loop Compensator */

