////////////////////////////////////////////////////////////////////////////////
// � 2015 Microchip Technology Inc.
//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any 
//derivatives, exclusively with Microchip?s products. This software and any 
//accompanying information is for suggestion only.  It does not modify Microchip?s 
//standard warranty for its products.  You agree that you are solely responsible 
//for testing the software and determining its suitability.  Microchip has no 
//obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
//IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF
//NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS 
//INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE 
//IN ANY APPLICATION.
 
//IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL 
//OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE 
//SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR 
//THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S 
//TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED 
//THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

//MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS. 

////////////////////////////////////////////////////////////////////////////////
#define DISABLED 0
#define ENABLED 1

#define OFF  0
#define ON  1

#define DACOUTEN 0

#define PU_Q15 32767
#define PU_Q14 (PU_Q15>>1)
#define PU_Q13 (PU_Q14>>1)
#define PU_Q12 (PU_Q13>>1)
#define TURNSRATIO (float)25            // TX Turns Ration 25:1:1
#define ADCREF (float)3.3               // AVdd Voltage from Aux Supply
#define VO_SENSOR_GAIN  (float)0.222    // R79/(R79+R78+R77) = (1500/(1500+5230+20))
#define VIN_SENSOR_GAIN (float)0.111    // R83/(R83+R82) = (1500/(1500+12000)) 
#define I_SENSOR_GAIN (float) 0.8611    // R27/CTTurns * (1+ R17/R15)=(24.9/200 *(1+10000/1690))

#define VBASE (float)(ADCREF/VO_SENSOR_GAIN)    //  Voltage Base referred to secondary
#define IBASE (float)(ADCREF/I_SENSOR_GAIN * TURNSRATIO) //Current Base referred to secondary

#define VO_REF (float)12                // Output voltage reference in volts
#define VREF_INIT 1.5                   // Initial Reference voltage in volts
#define VO_MAX 13.5                     // Maximum output voltage in volts

#define VO_MIN 10                       // Minimum output voltage in volts
#define VO_SS  0.9                      // Minimum output voltage to begin softstart in volts
#define VO_3V 3                         // 3V
#define VO_0_5V 0.5                     // 0.5V

#define VIN_MAX  435                    // Maximum input voltage limit in volts
#define VIN_MIN  340                    // Minimum input voltage limit in volts
#define VIN_MAXBM 435                   // Maximum input voltage limit during BurstMode in volts
#define VIN_MINBM 340                   // Minimum input voltage limit during Burst Mode in volts
#define IV_MAX   78                     // Over Load current limit in amperes
#define IV_MAXBM 85                     // Over load current limit during burst mode in amperes
#define IV_MAXSS 85                     // Over load current limit during softstart in amperes
#define IV_ENTERBM 10                   // Threshold current for entry into burst mode in amperes
#define IV_EXITBM 15                    // Threshold current for exit from burst mode in amperes

#define VREF (int)(VO_REF/VBASE * PU_Q15)               // Reference voltage 
#define VREFINITQ15 (int) (VREF_INIT/VBASE * PU_Q15)    // Initial Reference Voltage
#define VO3V (int)(VO_3V/VBASE * PU_Q15)                // 3V for softstart checks
#define VO05V (int)(VO_0_5V/VBASE * PU_Q15)             // 0.5V for softstart checks

#define OVERLOADLIMIT (int)(IV_MAX/IBASE*PU_Q12)    // OverLoadLimit
#define OVERLOADLIMITBM (int)(IV_MAXBM/IBASE *PU_Q12)   //OverLoadLimit during BurstMode
#define OVERLOADLIMITSS (int)(IV_MAXSS/IBASE *PU_Q12)   // OverLoadLimit during Softstart
#define ENTERBURSTMODE (int) (IV_ENTERBM/IBASE*PU_Q12)  // Burst Mode entry threshold current
#define EXITBURSTMODE (int) (IV_EXITBM/IBASE*PU_Q12)    // Burst Mode exit threshold current

#define VOMIN (int) (VO_MIN/VBASE * PU_Q15) // Minimum output voltage limit
#define VOMAX (int) (VO_MAX/VBASE * PU_Q15) // Maximum output voltage limit
#define VOMINSS (int) (VO_SS/VBASE * PU_Q15) // Minimum output voltage limit during SoftStart


#define VINMAX (int) (VIN_MAX/(TURNSRATIO*VBASE) * PU_Q14)  //Maximum input voltage Limit
#define VINMIN (int) (VIN_MIN/(TURNSRATIO*VBASE)* PU_Q14)   //Minimum input voltage limit
#define VINMAXBM (int) (VIN_MAXBM/(TURNSRATIO*VBASE) * PU_Q14) //Maximum input voltage limit during Burst Mode
#define VINMINBM (int) (VIN_MINBM/(TURNSRATIO*VBASE)* PU_Q14)  // Minimum input voltage limit during Burst Mode

/* PI COMPENSATOR COEFFICIENTS IN Q12 FORMAT {KiQ12,KpQ12}*/
#define COEFFICIENTS    {2000, 28000}

/* PWM Timing Defines*/
#define PERIOD 13200                 /* Fsw = ~73kHz, Tsw = 13.7 us, PWM Resolution = 1.04ns*/
#define HALF_PERIOD (PERIOD/2)      
#define STATEMACHINEPERIOD 3500      /* State Machine runs at every 50us, clock = 70MHz */
#define DEADTIME 500                
#define DEADTIMEBM 1200
#define FAULTLEDPERIOD 50000

/* State Definitions*/
#define STARTUP 0
#define SOFTSTART 1
#define REGULATION 2
#define SHUTDOWNACTIVE 4            /* bit 2 for bit testing operation */
#define SHUTDOWNCOMPLETE 8

// I/O drive use case
#define SWITCHOVER      1
#define UART_CRC_GOOD   2
#define EZBL_TASK       3

#define IO_FUNCT        SWITCHOVER    

#define DRV_IO          LATBbits.LATB5 
#define DRV_IO_BTG()\
        __asm__("BTG LATB, #5");


#define DRV_LED     LATCbits.LATC8
#define DRV_LED_BTG() \
        __asm__("BTG LATC, #8");


#define IPK_CMPMAXQ15 0x7080              // Peak Current Max for CMPDAC set to 3602*8Q15 => 75A peak
#define IPK_CMPMINQ15 0x0000              // Peak Current Min for CMPDAC set to 0 counts
#define DMCIMAXCOUNT 0x0190

#define DUTYCYCLEMAX 0x7FF0                // Limit Duty Cycle Max to ~0.99 in Q15
#define DUTYCYCLEMIN 0x0147                // Limit Duty Cycle Min to ~0.01 in Q15

#define VINMINQ14 0x1134                    // 137*32 counts = 100V
#define VOMINQ15  0x00DC                    // 0.1V

#define Q11POSLIMIT  30000                  // ~14.64pu
#define Q11NEGLIMIT -30000                  // ~(-14.64)pu

//#define DMCI 0                           // Uncomment for using DMCI
#define VO5V 11000                         // VO5V = 5VQ15    

#define Ipeakcmpdacmax 0x0FA0              // ~4000 counts =>75A, Ri = 0.86Ohm, This is for releasing peak reference at the beginning of every cycle
#define Ipeakcmpdacmin 0x0000              // 0 counts
    
#define IpeakrefmaxQ13 0x7D00               // Peak Current Reference Max Limit set to ~3.9pu in Q13               
#define IpeakrefmaxQ11 0x1FFF               // Peak Current Reference Clamp to 3.999pu in Q11 format

#define VerrorQ15pLimit 32500               //Output Voltage Error clamped to +/- 1pu
#define VerrorQ15nLimit -32500               

/* Alpha Beta Filter Coefficients  for Vct voltage filtering */
/* Alpha - Beta Filter TF = y(s)/x(s) = (1+sTs/2) / ( 1+sTs/2 * (1+B)/A) */
#define ALPHAQ15 16383                       // Alpha =50%, present sample weightage
#define BETAQ15  16384                       // Beta = 50% , past sample weightage

#define CMPDACINIT 600                       // DAC Value during Startup
#define CMPDACMAXINIT 600                    // Maximum DAC Value during Startup

#define Ivalleyscaler 1                      // To convert Measured 12-bit ADC Valley Current to Q13 format
#define DACscaler 3                          // To Convert Q15 current reference to 12-bit
#define Vinscaler 3                          // To convert Measured 12-bit ADC CT voltage to Q14 format
#define Voscaler  3                          // To convert Measured 12-bit ADC Output voltage to Q15 format
    
#define SHORTCKTLIMIT       3900			    
#define SHORTCKTLIMITSS     4000		    
#define SHORTCKTCNTLIMIT    2    
#define SHORTCKTCNTLIMITSS  35    

#define DEADTIME                500
#define DEADTIMESYNC            500
#define CURRENTLOOPTRIG1        (DEADTIME+1000)
#define CURRENTLOOPTRIG2        (HALF_PERIOD+DEADTIME+1000)
#define POSCYCLEFLTCONFIG       (DEADTIME-DEADTIMESYNC+50) // TRIG3
#define NEGCYCLEFLTCONFIG       (HALF_PERIOD+DEADTIME+50)
#define DUTYSYNC                (HALF_PERIOD-DEADTIME)
#define PHASESYNC               (PERIOD-DEADTIME)
#define SPHASESYNC              (HALF_PERIOD-DEADTIME)

#define DEADTIMEBM              1200
#define DEADTIMEBMSYNC          500
#define CURRENTLOOPTRIG1BM      (DEADTIMEBM+1000)
#define CURRENTLOOPTRIG2BM      (HALF_PERIOD+DEADTIMEBM+1000)
#define POSCYCLEFLTCONFIGBM 	(DEADTIMEBM-DEADTIMEBMSYNC+50) // TRIG3 
#define NEGCYCLEFLTCONFIGBM 	(HALF_PERIOD+DEADTIMEBM+50)
#define DUTYSYNCBM              (HALF_PERIOD-DEADTIMEBMSYNC)
#define PHASESYNCBM         	(PERIOD - DEADTIMEBMSYNC)
#define SPHASESYNCBM    		(HALF_PERIOD - DEADTIMEBMSYNC)
