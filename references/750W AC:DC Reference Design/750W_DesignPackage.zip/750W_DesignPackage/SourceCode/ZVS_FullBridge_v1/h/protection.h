////////////////////////////////////////////////////////////////////////////////
// � 2015 Microchip Technology Inc.
//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any 
//derivatives, exclusively with Microchip?s products. This software and any 
//accompanying information is for suggestion only.  It does not modify Microchip?s 
//standard warranty for its products.  You agree that you are solely responsible 
//for testing the software and determining its suitability.  Microchip has no 
//obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
//IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF
//NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS 
//INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE 
//IN ANY APPLICATION.
 
//IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL 
//OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE 
//SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR 
//THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S 
//TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED 
//THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

//MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS. 

////////////////////////////////////////////////////////////////////////////////

#include "Defines.h"
#include "p33Exxxx.h"
#include "stdint.h"
#include "uart_comm.h"
#include "system.h"


/* LED blinking counts for the Faults 1-reserved for startup indication */
#define FAULT_OVERCURRENT                    2                  /* Num. LED blinks for Over current protection          */
#define FAULT_INPUTUNDERVOLTAGE              3                  /* Num. LED blinks for Input under voltage protection   */
#define FAULT_INPUTOVERVOLTAGE               4                  /* Num. LED blinks for input over voltage protection    */
#define FAULT_OUTPUTUNDERVOLTAGE             5                  /* Num. LED blinks for output under voltage protection  */
#define FAULT_OUTPUTOVERVOLTAGE              6                  /* Num. LED blinks for output over voltage protection   */
#define FAULT_UARTCOMM                       7                  /* Num. LED Blinks for UART communication failure       */
#define FAULT_PFCSIDE                        8                  /* Num. LED Blinks for fault on PFC side that doesnt cause fault on DCDC side */
//#define FAULT_OVERTEMP                       9

#define LED_TOGGLE_TIME                     6000        /* LED on/off period, 50u*6000 = 300ms */
#define LED_TOGGLE_DELAY                    24000       /* Delay between cycling, 50u*24000 = 1200ms */

static inline void FaultLED_Indicator(void);                               /* LED blinking function during the Fault Mode */

