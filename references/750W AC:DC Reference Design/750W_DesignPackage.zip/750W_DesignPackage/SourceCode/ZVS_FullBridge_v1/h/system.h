////////////////////////////////////////////////////////////////////////////////
// � 2015 Microchip Technology Inc.
//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any 
//derivatives, exclusively with Microchip?s products. This software and any 
//accompanying information is for suggestion only.  It does not modify Microchip?s 
//standard warranty for its products.  You agree that you are solely responsible 
//for testing the software and determining its suitability.  Microchip has no 
//obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
//IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF
//NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS 
//INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE 
//IN ANY APPLICATION.
 
//IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL 
//OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE 
//SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR 
//THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S 
//TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED 
//THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

//MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS. 

////////////////////////////////////////////////////////////////////////////////
#ifndef _SYSTEM_H
#define _SYSTEM_H

typedef union{

    struct {
        uint16_t overCurrent            : 1;
        uint16_t outputOverVoltage      : 1;
        uint16_t outputUnderVoltage     : 1;
        uint16_t inputOverVoltage       : 1;
        uint16_t inputUnderVoltage      : 1;
        uint16_t overTemp               : 1;
        uint16_t communication          : 1;
        uint16_t faultPFC               : 1;
        uint16_t : 8;
    };
    uint16_t wordWriteFaults;

} ZVSFB_FAULTS;


typedef union{

    struct {
        uint16_t  softStartActive       : 1;
        uint16_t  softStartComplete     : 1;
        uint16_t  compensatorEnabled    : 1;
        uint16_t  burstMode             : 1;
        uint16_t  ACMainsOffFlag        : 1;
        uint16_t  PFCVoltageReady       : 1;
        uint16_t  burstModeConfigComp   : 1;
        uint16_t  normalModeConfigComp  : 1;
        uint16_t  faultPFCSide          : 1;
        uint16_t : 7;
    };
    uint16_t wordWriteFlags;

} ZVSFB_FLAGS;

#endif
