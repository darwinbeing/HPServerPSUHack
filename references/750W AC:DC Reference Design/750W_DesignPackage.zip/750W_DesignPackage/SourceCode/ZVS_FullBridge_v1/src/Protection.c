////////////////////////////////////////////////////////////////////////////////
// � 2015 Microchip Technology Inc.
//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any 
//derivatives, exclusively with Microchip?s products. This software and any 
//accompanying information is for suggestion only.  It does not modify Microchip?s 
//standard warranty for its products.  You agree that you are solely responsible 
//for testing the software and determining its suitability.  Microchip has no 
//obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
//IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF
//NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS 
//INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE 
//IN ANY APPLICATION.
 
//IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL 
//OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE 
//SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR 
//THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S 
//TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED 
//THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

//MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS. 

////////////////////////////////////////////////////////////////////////////////
#include "protection.h"

/***************************************************************************
Function: 	T1Interrupt
Description: Timer1 ISR. Executed @20kHz. 
 * T1-ISR implements the protection software providing protection against 
 * OverLoad, InputUnderVoltage,InputOverVoltage, OutputUnderVoltage &OutputUnderVoltage.
 * T1-ISR  implements softstart and SystemState flag updates.
 * T1-ISR reads data from PFC stage over UART
 * T1-ISR implements FaultLED flashing software
 ***************************************************************************/	

int16_t coeff[2]  __attribute__ ((space(xmemory))) = COEFFICIENTS;            /* {Ki,Kp} */
int16_t hist[3]   __attribute__ ((space(ymemory), far)) = {0,0,0};            /* { ui[n-1]LSW, ui[n-1]MSW,  e[n-1]}*/

int16_t slope_params[2]    __attribute__ ((space(xmemory))) = {0,0};          /*  {d[n]Q15,ddash[n]Q15 }*/
int16_t measured_data[3]   __attribute__ ((space(ymemory), far)) = {0,0,0};   /* {vo[n]Q15, vin[n]Q14, ivalley[n]Q13}*/
int16_t slope_currents[2]  __attribute__ ((space(ymemory), far)) = {0,0};     /* { Ivalley[n]Q13, Ipeakref[n]Q13} */

int16_t Iavg = 0, Ivalley = 0, ShortCktCounter = 0;
int16_t VrefQ15 = 0, Vinavg = 0, Ipeakrefcmp = 0;

static int16_t VinavgThresholdMax = 0, VinavgThresholdMin = 0, IavgThresholdMax = 0;             
static uint16_t timerInterruptCounter = 0;
static uint8_t faultLEDToggleCounter = 0, overLoadCntLimit = 0;
static uint8_t outputVoltageFltCnt = 0, softStartCounter = 0;
static uint8_t avgCounter = 0, EnterBurstModeCounter = 0; 
static uint8_t CompensatorEnableCounter = 0, OverLoadCounter = 0;
static uint8_t InputOverVoltageCounter = 0, InputUnderVoltageCounter = 0;
static uint8_t faultLEDState = 0;
uint8_t  ExitBurstModeCounter = 0, faultState = 0;
volatile uint8_t SystemState = STARTUP;


static int16_t Vinbuffer[32];

volatile ZVSFB_FAULTS __attribute__((near)) systemFaults;
volatile ZVSFB_FLAGS __attribute__((near)) systemFlags;


void __attribute__((__interrupt__ , no_auto_psv)) _T1Interrupt()  
{
    
/****State Codes: SystemStartup = 0, SoftStart = 1, Regulation = 2,   **********
 * ShutdownActive = 4, ShutdownComplete = 8                             *******/
    if((systemFaults.wordWriteFaults != DISABLED) && (SystemState != SHUTDOWNCOMPLETE))
    {
        SystemState = SHUTDOWNACTIVE;                       /* Activate Shutdown*/
        systemFlags.compensatorEnabled = DISABLED;         /* Disable compensator*/
    }
  
   switch(SystemState)
   {
        case STARTUP:
               
        if(measured_data[0] > VOMINSS)
        {   
            if(++CompensatorEnableCounter > 15)
            {
                systemFlags.compensatorEnabled = 1;        /* Raise Compensator Enable Flag*/
                SystemState = SOFTSTART;                   /* SystemState = SoftStart*/

                // Ensure all necessary variables are reset
                softStartCounter = 0;
                hist[0] = hist[1] = hist[2] = 0;
                
                systemFlags.softStartActive = 1;                  
                VrefQ15 = measured_data[0]+50;      // At first entry to softstart  VrefQ15 greater than present output voltage
            }
        }
        else
        {
            CompensatorEnableCounter = 0;                    /* Reset Compensator Enable Counter*/
        }
           
        break;
       
       
       case SOFTSTART:
                     
        if(VrefQ15 >= VREF)
        {
            VrefQ15 = VREF;

           if(++softStartCounter > 4)        /* Wait for the output voltage to reach regulation*/
           {
                systemFlags.softStartActive = 0;
                softStartCounter = 0;
                SystemState = REGULATION;
           }
        }
        else
        {
            VrefQ15 += 7;               /* Increment VrefQ15*/

            if(measured_data[0] > (VrefQ15 + 250))
            {
                VrefQ15 = measured_data[0] + 50;      /* To Keep Error Positive */
            }

            if((measured_data[0] < (VrefQ15-VO05V)) && (VrefQ15 > VO3V))
            {
                if(++softStartCounter > 50)
                {
                    systemFaults.outputUnderVoltage = 1;
                    if(faultState == DISABLED)
                        faultState = FAULT_OUTPUTUNDERVOLTAGE;    
                }
            }
            else
            {
                softStartCounter = 0;  //Reset SoftwareVoltageFallCounter
            }
        }

        if(Iavg > OVERLOADLIMITSS)
        {
            if(++OverLoadCounter > 5)
            {
                systemFaults.overCurrent = 1;
                if(faultState == DISABLED)
                    faultState = FAULT_OVERCURRENT;
            }
        }
       
           break;
       
           
       case REGULATION:
           
        faultState = DISABLED;   
           
        if((systemFlags.burstMode == DISABLED) && (ExitBurstModeCounter == DISABLED))
        {
            VinavgThresholdMin = VINMIN;
            IavgThresholdMax = OVERLOADLIMIT;
            overLoadCntLimit = 10;
        }
        else {  
            VinavgThresholdMin = VINMINBM;
            IavgThresholdMax = OVERLOADLIMITBM;
            overLoadCntLimit = 5;
        }
        
        if(Vinavg < VinavgThresholdMin)              
        {
            if(++InputUnderVoltageCounter > 100)
            {
                systemFaults.inputUnderVoltage = 1;
                if(faultState == DISABLED)
                    faultState = FAULT_INPUTUNDERVOLTAGE;
            }
        }
        else {
            InputUnderVoltageCounter = 0;
        }

        if(Iavg > IavgThresholdMax)
        {
            if(++OverLoadCounter > overLoadCntLimit)
            {
                systemFaults.overCurrent = 1;
                if(faultState == DISABLED)
                    faultState = FAULT_OVERCURRENT;
            }
        }
        else {
            OverLoadCounter = 0;
        }
        
        /*******************BURST MODE (LIGHT LOAD) DETECTION *************/
        if((Ipeakrefcmp < ENTERBURSTMODE) && (systemFlags.burstMode == DISABLED))
        {
            if(++EnterBurstModeCounter >= 10)
            {
                systemFlags.burstMode = 1;
                EnterBurstModeCounter = 0;
            }
        }
        else {
           EnterBurstModeCounter = 0;   
        }
        
           break;
         
    case SHUTDOWNACTIVE:
        Nop();
        //Code for shutdown handled inside VoltageCompensator.S
        
        break;
        
    case SHUTDOWNCOMPLETE:
        Nop();
        // Code for restart could go here but currently not implemented this way
        
        break;
   }        


/*******************************************************************************
Functionality: Moving Average Filter
Description: Add current sample with summed value and discard latest
*******************************************************************************/
   Vinavg = Vinavg - Vinbuffer[avgCounter];
    Vinbuffer[avgCounter] = measured_data[1] >> 5;
    Vinavg = Vinavg + Vinbuffer[avgCounter];
 
    if(++avgCounter >= sizeof(Vinbuffer)/sizeof(Vinbuffer[0]))
    {
        avgCounter = 0;
    }
  

/*******************************************************************************
Functionality: Input Over Voltage Fault
Description: When input voltage > 420V system will enter in Fault mode
*******************************************************************************/
    if((systemFlags.burstMode == DISABLED) && (ExitBurstModeCounter == DISABLED))
    {
        VinavgThresholdMax = VINMAX;
    }
    else {
        VinavgThresholdMax = VINMAXBM;
    }    
  
    if(Vinavg > VinavgThresholdMax) 
    {
        if(++InputOverVoltageCounter > 200)
        {
            systemFaults.inputOverVoltage = 1;
            if(faultState == DISABLED)
                 faultState = FAULT_INPUTOVERVOLTAGE;
        }
    }
    else {
        InputOverVoltageCounter = 0;
    }
    
    
/*******************************************************************************
Functionality: Output Over/Under Voltage Fault
Description: When output voltage < 10V, or > 13.5V system will enter in Fault mode
*******************************************************************************/
    if((measured_data[0] < VOMIN) && (SystemState == REGULATION))
    {
        if(++outputVoltageFltCnt > 10)
        {
            systemFaults.outputUnderVoltage = 1;
            if(faultState == DISABLED)
                faultState = FAULT_OUTPUTUNDERVOLTAGE;
        }
    }
    else if((measured_data[0] > VOMAX))
    {
        if(++outputVoltageFltCnt > 10)
        {
            systemFaults.outputOverVoltage = 1;
            if(faultState == DISABLED)
                faultState = FAULT_OUTPUTOVERVOLTAGE;            
        }
    }
    else {
        outputVoltageFltCnt = 0;
    }    
  
/*******************************************************************************
Functionality: Fault indication for communication Failure
Description: UART_comm.c will flag failure when CRC doesn't match 
*******************************************************************************/    
    if(systemFaults.communication == ENABLED)
    {
        if(faultState == DISABLED)
            faultState = FAULT_UARTCOMM;
    }  
    
    if(systemFaults.faultPFC == ENABLED)
    {
        if(faultState == DISABLED)
            faultState = FAULT_PFCSIDE;          
    }
  
    /* Call Fault routine if any fault is present */
    if(systemFaults.wordWriteFaults != DISABLED)
    {
        if(timerInterruptCounter) 
            timerInterruptCounter--;  
        else {
            FaultLED_Indicator();                                  
        } 
    }
    else {
        DRV_LED = OFF;
        faultLEDState = 0;
        timerInterruptCounter = 0;
        faultLEDToggleCounter = 0;
    }    
             
    _T1IF = 0;            // Reset Timer1IF
}

/*******************************************************************************
Function: 		FaultLED Indication
Description:	When in fault mode, LED will blink based on FaultState
*******************************************************************************/
static inline void __attribute__((always_inline, optimize(1))) FaultLED_Indicator(void)
{
    switch(faultLEDState)
    {
        case 0:
            DRV_LED = ON;
            timerInterruptCounter = LED_TOGGLE_TIME;
            faultLEDState = 1;
        break;
        case 1:
            DRV_LED = OFF;
            timerInterruptCounter = LED_TOGGLE_TIME;
            faultLEDState = 2;
        break;
        case 2:
            faultLEDToggleCounter++;
            if(faultLEDToggleCounter >= faultState)
            {
                timerInterruptCounter = LED_TOGGLE_DELAY;
                faultLEDToggleCounter = 0;
            }
            else {
                timerInterruptCounter = 0;
            }
            
            faultLEDState = 0;        
        break;

        default:
            faultLEDState = 0;
        break;

    }
    
}



