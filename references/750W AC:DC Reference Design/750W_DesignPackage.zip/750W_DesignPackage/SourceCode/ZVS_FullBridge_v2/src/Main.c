////////////////////////////////////////////////////////////////////////////////
// � 2015 Microchip Technology Inc.
//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any 
//derivatives, exclusively with Microchip?s products. This software and any 
//accompanying information is for suggestion only.  It does not modify Microchip?s 
//standard warranty for its products.  You agree that you are solely responsible 
//for testing the software and determining its suitability.  Microchip has no 
//obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
//IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF
//NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS 
//INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE 
//IN ANY APPLICATION.
 
//IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL 
//OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE 
//SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR 
//THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S 
//TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED 
//THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

//MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS. 

////////////////////////////////////////////////////////////////////////////////

#include "main.h"
#include "libpic30.h"

/* CONFIGURATION REGISTERS SETTINGS */
// FSEC
#pragma config BWRP = OFF               // Boot Segment Write-Protect bit (Boot Segment may be written)
#pragma config BSS = DISABLED           // Boot Segment Code-Protect Level bits (No Protection (other than BWRP))
#pragma config BSEN = OFF               // Boot Segment Control bit (No Boot Segment)
#pragma config GWRP = OFF               // General Segment Write-Protect bit (General Segment may be written)
#pragma config GSS = DISABLED           // General Segment Code-Protect Level bits (No Protection (other than GWRP))
#pragma config CWRP = OFF               // Configuration Segment Write-Protect bit (Configuration Segment may be written)
#pragma config CSS = DISABLED           // Configuration Segment Code-Protect Level bits (No Protection (other than CWRP))
#pragma config AIVTDIS = OFF            // Alternate Interrupt Vector Table bit (Disabled AIVT)

// FBSLIM
#pragma config BSLIM = 0x1FFF           // Boot Segment Flash Page Address Limit bits (Boot Segment Flash Page Address Limit (0-0x1FFF))

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Source Selection (Internal Fast RC (FRC))
#pragma config IESO = OFF               // Two-speed Oscillator Start-up Enable bit (Start up with user-selected oscillator source)

// FOSC
#pragma config POSCMD = NONE            // Primary Oscillator Mode Select bits (Primary Oscillator disabled)
#pragma config OSCIOFNC = OFF           // OSC2 Pin Function bit (OSC2 is clock output)
#pragma config IOL1WAY = OFF            // Peripheral pin select configuration (Allow multiple reconfigurations)
#pragma config FCKSM = CSECMD           // Clock Switching Mode bits (Both Clock switching and Fail-safe Clock Monitor are enabled)
#pragma config PLLKEN = ON              // PLL Lock Enable Bit (Clock switch to PLL source will wait until the PLL lock signal is valid)

// FWDT
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler bits (1:32,768)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config WDTEN = OFF              // Watchdog Timer Enable bits (WDT and SWDTEN disabled)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)
#pragma config WDTWIN = WIN25           // Watchdog Timer Window Select bits (WDT Window is 25% of WDT period)

// FICD
#pragma config ICS = PGD3               // ICD Communication Channel Select bits (Communicate on PGEC3 and PGED3)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)
#pragma config BTSWP = ON               // Enable bootswp instruction

// FDEVOPT
#pragma config PWMLOCK = OFF            // PWMx Lock Enable bit (PWM registers may be written without key sequence)
#pragma config DBCC = ON                // DACx Output Cross Connection bit (Interconnects DACOUT1 and DACOUT2)

// FALTREG
#pragma config CTXT1 = IPL7  //CurrentLoop          // Specifies Interrupt Priority Level (IPL) Associated to Alternate Working Register 1 bits (Not Assigned)
#pragma config CTXT2 = IPL5  //VoltageLoop          // Specifies Interrupt Priority Level (IPL) Associated to Alternate Working Register 2 bits (Not Assigned)

#if defined(__DUAL_PARTITION)
EZBL_SET_CONF(_FBOOT, BTMODE_DUAL)  // Default is BTMODE_SINGLE, BTMODE_DUAL is for ping-ponging, BTMODE_DUALPROT is for statically write-protecting Partition 1, BTMODE_DUALPRIV is reserved/do not use
#endif


extern uint8_t __attribute__((update, persistent)) firstPassAfterSoftSwap;
extern int16_t coeff[2]  __attribute__ ((space(xmemory)));

uint8_t __attribute__((update, persistent)) exitTransientCounter;

volatile uint16_t __attribute__((near)) timeForPartitionSwap = 0, criticalISRDone = 0;

extern EZBL_FIFO UART_TxFifoPFC;

extern volatile ZVSFB_FAULTS __attribute__((near)) systemFaults;
extern volatile ZVSFB_FLAGS __attribute__((near)) systemFlags;

void __attribute__((priority(100), optimize(1))) CriticalInit(void)
{
    firstPassAfterSoftSwap = 0;  // Needs to be appropriately initialized at start-up and live update event
    exitTransientCounter = 0;
    
    if(!_SFTSWP)      
        return;
 
    // Ensure new variables are cleared/initialized appropriately upon Live Update event  
    systemFlags.newController = 0;
    systemFlags.transientFlag = 0;
    
    #if (IO_FUNCT == SWITCHOVER) 
       DRV_IO = DISABLED;
    #endif 
    
    // Re-enable interrupts for controller - Note new controller hasn't been modified yet 
    _ADCAN0IE = 1;
    _ADCAN1IE = 1;
    _PWM3IE = 1;
    _PSEMIE = 1;
}    

void __attribute__((priority(200), optimize(1))) SecondaryInit(void)
{
    if(!_SFTSWP)      
        return;

    // Re-enable protection timer ISR and IC-IC communications
    _T1IE = 1;      // Timer 1 System Code

    UART1_RxFifo.onReadCallback = UART1_RX_FIFO_OnRead;
    UART1_TxFifo.onWriteCallback = UART1_TX_FIFO_OnWrite;
    UART1_RxFifo.flushFunction   = UART1_RX_FIFO_Flush;
    UART1_TxFifo.flushFunction   = UART1_TX_FIFO_Flush;
        
    _U1TXIE = 1;    // UART 1 TX PFC Communication
    _U1RXIE = 1;    // UART 1 RX PFC Communication
    _T5IE = 1;
}

int main (void)
{    
    if((RCONbits.TRAPR == 1) || (RCONbits.IOPUWR == 1))
    {
        TRISBbits.TRISB5 = 0;
        while(1)       // Do not proceed , device reset not intended
        {
            LATBbits.LATB5 = 1;
            __asm("repeat, #10"); Nop();
            LATBbits.LATB5 = 0;
            __asm("repeat, #10000"); Nop();
        }
    } 
    
    // Check if we are entering main via an ordinary device reset or via a hot 
    // Bootloader partition swap
    if(!_SFTSWP)    // Ordinary reset initialization - do not execute for live update
    {      
        systemFaults.wordWriteFaults = 0;
        systemFlags.wordWriteFlags = 0;
        systemFlags.normalModeConfigComp = 1;
        systemFlags.newController = 1;
        
        // Initialize the bootloader as the very first thing to minimize bricking 
        // possibilities. This will block for 1 second to give a small bootloading 
        // "guaranteed" window.//
        EZBL_BootloaderInit();
        
        init_CLOCKS();    
        init_IO(); 
        init_TIMER();         
        uartCommFunct();
      
        while(systemFlags.PFCVoltageReady == 0);   /*Wait for DC-Bus Voltage to reach steady state*/
        
        init_ALTWREG();
        init_PWM();  
        init_ADC();
        init_CMP(); 
        PWMStart();       
    }
    else {
        NVMCONbits.SFTSWP = 0;   
        
        #if (IO_FUNCT == SWITCHOVER) 
            DRV_IO = ENABLED;
        #endif 
        
        // Execute controller change over now that new transient code is being called
        Delay(Delay20us); 
        while(systemFlags.transientFlag == ENABLED);
        
        // Not in the middle of transient condition (change controller)
        _GIE = DISABLED; Nop(); Nop();      // Disable all interrupts for few cycles to change controller over
        /*Re-initialize new compensator coefficients*/
        coeff[0]= KIQ13;
        coeff[1]= KPQ10;

        /*Raise Modify History from Q27 format to Q28 format due to Ki (Q12 -> Q13)*/
        firstPassAfterSoftSwap = 1;
        systemFlags.newController = 1;  
        
        _GIE = ENABLED;
        
        // Lowest Priority features to be re-enabled
        UART2_RxFifo.onReadCallback = UART2_RX_FIFO_OnRead;
        UART2_TxFifo.onWriteCallback = UART2_TX_FIFO_OnWrite;
        UART2_RxFifo.flushFunction   = UART2_RX_FIFO_Flush;
        UART2_TxFifo.flushFunction   = UART2_TX_FIFO_Flush;
      
        EZBL_bootloaderTask.callbackFunction = EZBL_BootloaderTaskFunc;
    
        _T2IE = 1;      // Timer 2 NOW tick timing code (now.c)
        _U2TXIE = 1;    // UART 2 TX EZBL Bootloader FIFO code
        _U2RXIE = 1;    // UART 2 RX EZBL Bootloader FIFO code
        
        #if (IO_FUNCT == SWITCHOVER) 
            DRV_IO = DISABLED;
        #endif 
    }
    
	while(1)
	{ 		
        Nop();
                    
        if(timeForPartitionSwap)
        {
            timeForPartitionSwap = 0;
            
            // Disable all interrupts except for the critical interrupts
            // which we want to synchronize the bootswap with
            _T1IE = 0;      // Timer 1 System Code
            _T2IE = 0;      // Timer 2 NOW tick timing code (now.c)
            _U2TXIE = 0;    // UART 2 TX EZBL Bootloader FIFO code
            _U2RXIE = 0;    // UART 2 RX EZBL Bootloader FIFO code
            _T5IE = 0;      // Timer for IC-IC communications
            _U1TXIE = 0;    // UART 1 TX PFC Communication
            _U1RXIE = 0;    // UART 1 RX PFC Communication           
            
            criticalISRDone = 0;            // Clear variable, PWM3 ISR set bit 0, ADCAN0 sets bit 1 
            while(criticalISRDone != 3u);   // Wait for variable to change, indicating the ISRs have just finished
            
            #if (IO_FUNCT == SWITCHOVER) 
               DRV_IO = ENABLED;
            #endif 
            
            EZBL_PartitionSwap();           // Perform the partition swap and branch to 0x000000 on the (presently) Inactive Partition
        }           
    }
    
    return 0;      
}

/***************************************************************************
Function: 	PWMStart
Description: The PWM Module is enabled and the PWM Pins are handed over control
 * by as recommended by Errata Document (Errata#32 Workaround)
 ***************************************************************************/	

void PWMStart(void)
{
    /* Errata 32 workaround*/
    PTCONbits.PTEN = 1;                             /* Enable the PWM*/
    IOCON1bits.OVRENH = 0;
    IOCON1bits.OVRENL = 0;
    IOCON2bits.OVRENH = 0;                          /* Disable Overrides*/
    IOCON2bits.OVRENL = 0;
    IOCON3bits.OVRENH = 0;
    IOCON3bits.OVRENL = 0;
    Delay_Us(Delay200us);                            
    IOCON1bits.PENL =1;                             /* Turn ON Bottom MOSFETs*/
    IOCON2bits.PENL =1;                             
    IOCON3bits.PENH =1;                             /* Turn ON Sync Rectification*/
    IOCON3bits.PENL =1;
    Delay_Us(Delay200us);                           /* Allow Boot Strap Cap to charge*/
    IOCON1bits.PENH =1;                             /* Turn ON Top MOSFETs*/
    IOCON2bits.PENH =1;
}