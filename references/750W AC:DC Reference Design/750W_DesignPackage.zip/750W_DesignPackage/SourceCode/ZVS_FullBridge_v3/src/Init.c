////////////////////////////////////////////////////////////////////////////////
// � 2015 Microchip Technology Inc.
//
// MICROCHIP SOFTWARE NOTICE AND DISCLAIMER:  You may use this software, and any 
//derivatives, exclusively with Microchip?s products. This software and any 
//accompanying information is for suggestion only.  It does not modify Microchip?s 
//standard warranty for its products.  You agree that you are solely responsible 
//for testing the software and determining its suitability.  Microchip has no 
//obligation to modify, test, certify, or support the software.
//
// THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
//IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF
//NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS 
//INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE 
//IN ANY APPLICATION.
 
//IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL 
//OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE 
//SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR 
//THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S 
//TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED 
//THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

//MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS. 

////////////////////////////////////////////////////////////////////////////////

#include "p33Exxxx.h"  
#include "Defines.h"
#include "delay.h"
#include "stdint.h"

/***************************************************************************
Function: 	init_CLOCKS
Description: Initialize Main and Auxilliary Clocks
***************************************************************************/	


void init_CLOCKS(void)
{
    /* PRIMARY OSCILLATOR CLOCK CONFIGURATION*/
    /* Configure Oscillator to operate the device at 70 Mhz  (70 MIPS)*/
    /* Fosc= Fin*M/(N1*N2), 	*/
    /* Fosc= 7.37M*(74+2)/(2*2)=140.03Mhz for 7.37M input clock*/
    /* Fcy = Fosc/2 = ~70MHz*/
    PLLFBD=74;                                      /* M= (PLLFBD+2) = 76*/
    CLKDIVbits.PLLPOST=0;                           /* N2=2*/
    CLKDIVbits.PLLPRE=0;                            /* N1=2*/

    RCONbits.SWDTEN=0;                       /* Disable Watch Dog Timer*/

    /* Clock switch to incorporate PLL*/
    // Initiate Clock Switch to FRC oscillator with PLL (NOSC=0b001)
    __builtin_write_OSCCONH(0x01);
    __builtin_write_OSCCONL(OSCCON | 0x01);
    // Wait for Clock switch to occur
    while (OSCCONbits.COSC!= 0b001);
    // Wait for PLL to lock
    while (OSCCONbits.LOCK!= 1){}  ;

    /* AUXILLARY CLOCK CONFIGURATION FOR ADC-PWM*/
    /* Setup the ADC and PWM clock for 120MHz; ((FRC * 16) / APSTSCLR ) = (7.37 * 16) / 1 = ~ 120MHz*/

     ACLKCONbits.FRCSEL = 1;    			/*FRC provides input for Auxiliary PLL (x16)*/
     ACLKCONbits.SELACLK = 1;   			/*Auxiliary Oscillator provides clock source for PWM & ADC*/
     ACLKCONbits.APSTSCLR = 7;  			/*Divide Auxiliary clock by 1 */
     ACLKCONbits.ENAPLL = 1;    			/* Enable Auxiliary PLL */
     OSCTUN = 4;                            /* Tune FRC Oscillator to obtain ACLK = 119.68MHz for ~1.04ns PWM resolution*/
     while(ACLKCONbits.APLLCK != 1);  		/* Wait for Auxiliary PLL to Lock*/
     Delay(Delay50us);       
}

/***************************************************************************
Function: 	init_IO
Description: Initialize all used port pins
 ***************************************************************************/	

void init_IO(void)
{
    /************* Bit Initializations for Erratum#32 Workaround*******************/
    TRISAbits.TRISA4    = 1;                        /* Setting PWM1H as Input port*/
    TRISAbits.TRISA3    = 1;                        /* Setting PWM1L as Input port*/
    TRISBbits.TRISB13   = 1;                        /* Setting PWM2H as Input port*/
    TRISBbits.TRISB14   = 1;                        /* Setting PWM2L as Input port*/
    TRISBbits.TRISB11   = 1;                        /* Setting PWM3H as Input port*/
    TRISBbits.TRISB12   = 1;                        /* Setting PWM3L as Input port*/
  
    TRISBbits.TRISB3    = 0;                        /* Configure RB3/RP3/DACOUT as output*/
    TRISCbits.TRISC4    = 0;                        /* Configure PMBUSAUX1-- Header pin6 as output for debugging*/
    TRISBbits.TRISB5    = 0;                        /* Configure PMBUSAUX2-- Header pin1 as output for debugging*/

    RPINR12bits.FLT1R = 0b000000;                   /* FAULT1 mapped to Vss for disabling of faults for PWM1 and PWM2*/

    TRISCbits.TRISC5 = 0;                           /* Configure RC5(pin:3) as Enable1 for enabling/disabling Q5*/
    TRISCbits.TRISC6 = 0;                           /* Configure RC6(pin:4) as Enable2 for enabling/disabling Q7*/
    TRISCbits.TRISC8 = 0;                           /* Fault LED */

    LATCbits.LATC5 = 1;                             /* Enable Q5 Sec MOSFET*/
    LATCbits.LATC6 = 1;                             /* Enable Q7 Sec MOSFET*/
    LATCbits.LATC8 = 0;                             /* Initialize Fault LED to low */

    /* Set All port pins to Digital Mode*/
    ANSELA = 0;                           // All Port A Pins Set to Digital Mode
    ANSELB = 0;                           // All Port B Pins Set to Digital Mode
    ANSELC = 0;                           // All Port C Pins Set to Digital Mode    

    __builtin_write_OSCCONL(0x00);                  /* Release IOLOCK -> IOLOCK = 0*/
    /**********************Configure UART PINS************************/
    _U1RXR = 60;   /* Pin20 of device (RP60)  = pin16 of Control Card = U1RX (PSFB)*/
    _RP59R = _RPOUT_U1TX;     /* Pin19 of device (RP59)  = pin17 of control card = U1TX (PSFB)*/

   __builtin_write_OSCCONL(0x40);                  /* Lock I/O ports IOLOCK = 1*/

   /********SET CORCON BITS***********************************/
   CORCONbits.IF = 1;               /* Choose Integer Mode */
   CORCONbits.SATA =1;              /* Enable Saturation of ACCA used in SlopeCompLoop */            
}

/***************************************************************************
Function: 	init_PWM
Description:	initialze the High Speed PWM Generators. 
 * Configure PWM1H,PWM1L,PWM2H and PWM2L for Full Bridge Drive
 * Configure PWM3H, PWM3L for Synchronous Rectifier Drive
 * Configure TRIG1 for sampling Valley Current
 * Configure TRIG2 for sampling Output Voltage
 * Configure SEVTCMP for triggering fault configuration ISR
 * Configure TRIG3 for triggering fault configuration ISR
***************************************************************************/	

void init_PWM(void)
{
    PTPER = PERIOD;                                     /* PWM Switching Period Set to ~73kHz*/
    PTCONbits.SEIEN =1;                                 /* Enable PWM Special Event Interrupt for negative cycle Fault Initialization*/
    SEVTCMP = HALF_PERIOD+DEADTIME+50;                  /* Update Faults for PWM2 and sets max value for CMPDAC3 */
    IFS3bits.PSEMIF =0;
    IEC3bits.PSEMIE =1;
    IPC14bits.PSEMIP =6;                                /* IPL = 6*/

    /* PWM GENERATOR 1 INITIALIZATION*/
    IOCON1bits.PENH = 0;                                /* Initially GPIO module controls PWM1H/PWM1L pins -->Erratum#32 workaround*/
    IOCON1bits.PENL = 0;
    IOCON1bits.PMOD = 0;                                /* PWM1 set to complementary mode*/
    IOCON1bits.OVRDAT = 0b00;                           /* TurnOFF both PWM1H/PWM1L during override*/
    IOCON1bits.CLDAT  = 0b01;                           /* On occurence of peak current PWM1H = 0 and PWM1L = 1 after deadtime*/
    IOCON1bits.FLTDAT = 0b00;
    IOCON1bits.OVRENH = 1;                              /* Enable Overrides Erratum#32 workaround*/
    IOCON1bits.OVRENL = 1;

    PDC1    = (PTPER >>1);
    DTR1    = DEADTIME;
    ALTDTR1 = DEADTIME;
    FCLCON1 = 0x0003;                                   /* Disable all faults*/
    TRGCON1bits.DTM  = 1;                               /* Enable Dual Trigger*/

    TRIG1 = 1500;                                        /* Trigger for ADCAN0, for slope comp calcs (Positive Cycle) */
    STRIG1= HALF_PERIOD+1500;                            /* Trigger for ADCAN0, for slope comp calcs (Negative Cycle) */

    /* LEBCON1 --> PHR,PHF,PLR,PLF,FLTLEBEN,CLLEBEN,X,X,X,X,BCH,BCL,BPHH,BPHL,BPLH,BPLL*/
    /* LEBDLY1 = X,X,X,X,LEB<8:0>,X,X,X*/
    //    LEBCON1bits.PHR =   1;
    //    LEBCON1bits.CLLEBEN  =   1;
          LEBCON1 = 0x8400;                             
          LEBDLY1 = 0x0400;     /* Delay ~1.06us*/

    /* PWM GENERATOR 2 INITIALIZATION*/

    IOCON2bits.PENH = 0;                                /* Initially GPIO module controls PWM2H/PWM2L pins -->Erratum#32 workaround workaround*/
    IOCON2bits.PENL = 0;
    IOCON2bits.PMOD = 0;                                /* PWM2 set to complementary mode*/
    IOCON2bits.OVRDAT = 0b00;                           /* TurnOFF both PWM2H/PWM2L during override*/
    IOCON2bits.CLDAT  = 0b01;                           /* On occurence of peak current PWM2H = 0 and PWM2L = 1 after deadtime*/
    IOCON2bits.FLTDAT = 0b00;
    IOCON2bits.OVRENH = 1;                              /* Disable Overrides Erratum#32 workaround*/
    IOCON2bits.OVRENL = 1;

    PHASE2 = (PTPER>>1);                              /* PWM2 is phase shifted w.r.t PWM1 by 180deg*/
    PDC2   = (PTPER>>1) ;

    DTR2    = DEADTIME;
    ALTDTR2 = DEADTIME;

    FCLCON2 = 0x0003;                                    /* Disable all faults*/
    TRIG2 = 3100;                                        /* Trigger Vo measurement */
      
    
    /* LEBCON2 --> PHR,PHF,PLR,PLF,FLTLEBEN,CLLEBEN,X,X,X,X,BCH,BCL,BPHH,BPHL,BPLH,BPLL*/
    /* LEBDLY2 = X,X,X,X,LEB<8:0>,X,X,X*/
    //    LEBCON2bits.PHR =   1;
    //    LEBCON2bits.CLLEBEN  =   1;
          LEBCON2 = 0x8400;                             
          LEBDLY2 = 0x0400;     /* Delay ~1.04us*/  
    /* PWM GENERATOR 3 CONFIGURATION (SYNCHRONOUS RECTIFICATION) */

    IOCON3bits.PENH = 0;                                /* Erratum#32 workaround*/
    IOCON3bits.PENL = 0;
    IOCON3bits.PMOD  = 3;
    IOCON3bits.OVRDAT = 0;

    IOCON3bits.OVRENH  = 1;
    IOCON3bits.OVRENL  = 1;                             /* Erratum#32 workaround*/

    IOCON3bits.OSYNC =1;                                /* Synchronize override of PWM3 with PWM Cycle boundary*/

    PDC3    = (PTPER>>1) - DEADTIME;
    SDC3    = (PTPER>>1) - DEADTIME;
    SPHASE3 = (PTPER>>1)-DEADTIME;
    PHASE3  = PTPER - DEADTIME;

    DTR3 = ALTDTR3 = 0;
    TRIG3 = 50;                                   /* Update Faults for PWM1 and sets max value for CMPDAC3 */
    PWMCON3bits.TRGIEN = 1;                       /* Enable PWM3 Interrupt for CMPDAC refresh + Fault update of PWM1*/
    IFS6bits.PWM3IF = 0;
    IEC6bits.PWM3IE = 1;
    IPC24bits.PWM3IP = 6;                         /* IPL = 6*/
    FCLCON3 = 0x0003;
    
}

/****************************************************************************************
Function: 	init_ADC
Description:	initialze the AD-Converter
 * Configure AN0 for Sampling Valley Current and enable ADCAN0 ISR for Slope Compensation
 * Configure AN1 for Sampling Output Voltage and enable ADCAN1 ISR for Voltage Compensator
 * Configure AN3 for Sampling Center Tap Voltage
****************************************************************************************/	
void init_ADC (void)   	
{
    ADCON2Lbits.EIEN = 0;                // Enable Early Interrupts
    ADCON3Hbits.CLKSEL = 1;               // Select ADC Module Clock Source as Fosc = 140MHz
    ADCON3Hbits.CLKDIV = 0;               // Default Clock divide = 1 =>140/2= 70MHz 
    ADCON3Lbits.REFSEL = 0;               // Default Reference is AVDD
    ADCON1Hbits.FORM = 0;                 // Integer Format
    ADCON4Lbits.SAMC0EN = 0;              // No delay between trigger and conversion
    ADCON4Lbits.SAMC1EN = 0;              // No delay between trigger and conversion
    
    ADCORE0Hbits.RES = 3;                 // Set Core0 to 12-bit Resolution
    ADCORE1Hbits.RES = 3;                 // Set Core1 to 12-bit Resolution
    ADCORE3Hbits.RES = 3;                 // Set Core3 to 12-bit Resolution
    
    ANSELAbits.ANSA0=1;                 // Set AN0 as analog channel
    TRISAbits.TRISA0 =1;                // Configure AN0 pin as Input
    ANSELAbits.ANSA1=1;                 // Configure AN1 as analog input
    TRISAbits.TRISA1=1;                 // Configure AN1 as input
    ANSELBbits.ANSB0=1;                 // Configure AN3 as analog input
    TRISBbits.TRISB0=1;                 // Configure AN3(RB0) as input
    
    /* Common ADC Configurations */
    ADCON5Hbits.WARMTIME = 15;
    ADCON1Lbits.ADON = 1;

                          
    /* CORE-0 CONFIGURATIONS, Ivalley Measurement*/
    ADCON5Lbits.C0PWR=1;                // Turn ON Analog Power for Core0
    while(ADCON5Lbits.C0RDY==0);        // Wait for Core to Turn ON
    ADCON3Hbits.C0EN=1;                 // Turn ON digital Power to Core0 to enable triggers
    
    ADCAL0Lbits.CAL0EN = 1;               // Enable calibration of Core-0
    ADCAL0Lbits.CAL0RUN = 1;
    while(ADCAL0Lbits.CAL0RDY == 0);      // Wait for Calibration to complete
    ADCAL0Lbits.CAL0EN = 0;               // End calibration of Core-0
    
    ADCORE0Hbits.EISEL = 1;               // Begin Interrupt 2 cycles before EOC
    ADEIELbits.EIEN0 = 1;                 // Enable Early Interrupt for AN0
    ADTRIG0Lbits.TRGSRC0 = 5;             // Configure Trigger source --TRIG1(DTM)--> AN0 for Ivalley Sense
    ADIELbits.IE0 = 1;                    // Enable AN0 Interrupt for Digital Slope COmpensation
    IPC27bits.ADCAN0IP = 7;               // Highest Priority for Digital Slope Compensation Loop

    /* CORE-1 CONFIGURATIONS Vout Measurement*/
    ADCON5Lbits.C1PWR=1;                // Turn ON Analog Power for Core1
    while(ADCON5Lbits.C1RDY==0);        // Wait for Core to Turn ON
    ADCON3Hbits.C1EN=1;                 // Turn ON digital Power to Core0 to enable triggers
    
    ADCAL0Lbits.CAL1EN = 1;               // Enable calibration of Core-1
    ADCAL0Lbits.CAL1RUN = 1;
    while(ADCAL0Lbits.CAL1RDY == 0);      // Wait for Calibration to complete
    ADCAL0Lbits.CAL1EN = 0;               // End calibration of Core-1
        
    ADCORE1Hbits.EISEL = 7;
    ADEIELbits.EIEN1 = 1;                // Enable Early Interrupt for AN1
    ADTRIG0Lbits.TRGSRC1 = 6;             // Configure Trigger source --TRIG2--> AN1 for Vo sense
    ADIELbits.IE1 = 1;                    // Enable AN1 Interrupt for Voltage Compensation
    IPC27bits.ADCAN1IP = 5;               // IPL = 5       
    
    /* CORE-3 CONFIGURATIONS Vin-ct Measurement*/
    ADCON5Lbits.C3PWR = 1;                // Turn ON Analog Power for Core3
    while(ADCON5Lbits.C3RDY == 0);        // Wait for Core to Turn ON
    ADCON3Hbits.C3EN = 1;                 // Turn ON digital Power to Core3 to enable triggers
    
    ADCAL0Hbits.CAL3EN = 1;               // Enable calibration of Core-3
    ADCAL0Hbits.CAL3RUN = 1;
    while(ADCAL0Hbits.CAL3RDY == 0);      // Wait for Calibration to complete
    ADCAL0Hbits.CAL3EN = 0;               // End calibration of Core-3
    
    ADTRIG0Hbits.TRGSRC3 = 1;             // Configure Trigger source --CSWTRG--> AN3 for Vin-ct sensing
    
    /* Enable ADC Interrupts*/
    IEC6bits.ADCAN0IE = 1;                    // Current Loop Interrupt Enable
    IEC6bits.ADCAN1IE = 1;                    // Voltage Loop Interrupt Enable
}

/***************************************************************************
Function: 	init_CMP
Description:	initialze ACMP3 and ACMP4 
 * Configure ACMP3 for Peak Current Control
 * Configure ACMP4 DAC (only)for debugging 
***************************************************************************/	

void init_CMP(void)

{
      CMP3CONbits.INSEL =  2;                /* Select CMP3C for peak current limiting */
      CMP3CONbits.RANGE  = 1;                /* Select AVDD (=3.33V) reference for DAC*/    
      CMP3CONbits.CMPPOL = 0;                /* Set normal polarity for comparator */
      CMP3CONbits.DACOE  = 0;                /* DAC output is disabled*/
      CMP3CONbits.CMPON  = 1;                /* Turn ON Comparator for In-Rush Current Protection*/
      CMP3CONbits.HYSSEL = 3;                 /* Hysteresis set to 20mV max */
      CMP3DACbits.CMREF =  300;               /* Initialize reference *///0.2417 V
      
      ANSELBbits.ANSB1  =1;                  /* Set Pin32 as analog input pin*/
      TRISBbits.TRISB1  =1;                  /* Configure Pin32 RB1 port as input pin */

#if(DACOUTEN == 1)
      ANSELBbits.ANSB3  = 1;                 /* Set RB3/DACOUT pin as an analog pin */
      CMP4CONbits.DACOE = 1;                 /*  CMPDAC4 output could be used for debugging */
      CMP4DACbits.CMREF =0;
      CMP4CONbits.RANGE =1;
      CMP4CONbits.CMPON =1;                  /* Turn ON Comparator for turning ON DAC*/ 
#endif      
}

/************************************************************************************
Function: 	init_TIMER
Description:	initialze Timer 1/5 Modules 
 * Configure Timer1 module for generating ISR @20kHz for running Protection Software
 * Configure Timer5 for generating RX/TX data between ICs
************************************************************************************/	

void init_TIMER(void)
{
   /* Initialize TIMER1 for StateMachine*/
    PR1 = STATEMACHINEPERIOD;
    T1CONbits.TCKPS = 0;             
                              
    _T1IF = 0;
    _T1IE = 1;
    
    T1CONbits.TON = 1;         
    
    // Timer 5 used for scheduling RX/TX between ICs
    T5CONbits.TCKPS = 1;
    PR5 = 17500;   //~2ms
    _T5IE = 1;
    // Enabled after setting up FIFOs
}


